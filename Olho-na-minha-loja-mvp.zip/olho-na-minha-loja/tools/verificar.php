<?php
// Diagnóstico somente pelo terminal. Não mostra credenciais nem envia e-mails.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/../includes/bootstrap.php';
$failures = 0;
function report_check($ok, $label) {
    global $failures;
    echo ($ok ? '[OK] ' : '[PENDENTE] ') . $label . PHP_EOL;
    if (!$ok) { $failures++; }
}
report_check(PHP_VERSION_ID >= 80300, 'PHP 8.3 ou superior');
report_check(extension_loaded('pdo_mysql'), 'Extensão PDO MySQL');
report_check(valid_http_url(app_url()) && parse_url(app_url(), PHP_URL_SCHEME) === 'https', 'Endereço da aplicação configurado com HTTPS');
try {
    $pdo = db();
    foreach (array('tenants','users','products','orders','order_items','page_views','click_events','password_resets','password_reset_limits') as $table) {
        $pdo->query('SELECT 1 FROM ' . $table . ' LIMIT 1');
        report_check(true, 'Tabela ' . $table);
    }
} catch (Throwable $e) { report_check(false, 'Conexão/tabelas do banco. Confira config.php e a importação do SQL.'); }
$mailFile = __DIR__ . '/../config.mail.php';
$mail = is_file($mailFile) ? require $mailFile : array();
report_check(!empty($mail['enabled']) && !empty($mail['from']) && filter_var($mail['from'], FILTER_VALIDATE_EMAIL) && function_exists('mail'), 'Remetente configurado e função de envio disponível');
echo PHP_EOL . 'Ainda é necessário testar HTTPS, permissões do Apache e recebimento de um e-mail real na hospedagem.' . PHP_EOL;
exit($failures ? 1 : 0);
