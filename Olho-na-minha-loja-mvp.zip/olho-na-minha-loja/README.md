# Olho na Minha Loja

Sistema multi-loja em PHP e MySQL/MariaDB. Cada cliente cria uma conta, recebe uma vitrine pública e acompanha produtos próprios ou afiliados, visitas, cliques, pedidos, receita e lucro. Não precisa ter um site próprio.

**Comece por `docs/COMECE-AQUI.md`.** Esse guia diferencia instalação nova e atualização sem perder configurações ou dados.

## Incluído

- Cadastro, login e recuperação de senha por e-mail.
- Uma loja por conta, com acesso aos dados filtrado por loja.
- Produtos próprios, estoque, ofertas afiliadas e links exclusivos.
- Visitas à vitrine e cliques antes do encaminhamento ao WhatsApp ou à oferta.
- Registro manual de pedidos, confirmação de pendentes e cancelamento.
- Baixa de estoque na confirmação e devolução no cancelamento de pedidos confirmados.
- Indicadores de receita, lucro e cliques; gráfico de receita em sete dias.
- Orientações simples com base nos indicadores.
- Formulários protegidos por CSRF, consultas preparadas, senhas com hash, limites de solicitações e tokens de recuperação de uso único.

## Requisitos

PHP 8.3 ou superior com PDO MySQL; banco MySQL/MariaDB com InnoDB; HTTPS; Apache com suporte ao `.htaccess`. O envio de recuperação usa `mail()` do PHP e exige serviço de e-mail local habilitado e remetente autorizado pela hospedagem. Não há dependências de Composer ou Node para rodar o site.

## Limites

Esta versão não tem checkout, integração automática de comissões/vendas, cobrança de assinatura, upload de mídia ou painel global do operador do SaaS. Vendas e custos são informados pelo lojista. Fotos usam links públicos. As métricas não medem visualizações dentro das redes sociais nem visitantes únicos.

## Arquivos principais

| Arquivo | Finalidade |
| --- | --- |
| `index.php` / `register.php` | Login e cadastro |
| `esqueci-senha.php` / `redefinir-senha.php` | Recuperação de acesso |
| `dashboard.php` | Indicadores e gráficos |
| `produtos.php` | Cadastro e edição de produtos |
| `pedidos.php` / `pedido_status.php` | Registro e situação dos pedidos |
| `loja.php` / `redirect.php` | Vitrine e registro de cliques |
| `config.php` | Banco, endereço e fuso |
| `config.mail.example.php` | Modelo da configuração de envio |
| `sql/database.sql` | Banco para instalação nova |
| `sql/atualizacao-recuperacao-senha.sql` | Migração sem apagar dados |
| `tools/verificar.php` | Diagnóstico pelo terminal |

Veja `docs/REVISAO-E-TESTES.md` para as correções e os limites da validação.
