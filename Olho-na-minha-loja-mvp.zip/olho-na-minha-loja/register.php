<?php
require __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/password_reset.php';

if (current_user()) {
    redirect_to('dashboard.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) {
        $error = 'A sessão expirou. Atualize a página e tente novamente.';
    } else {
        $storeName = post_value('store_name');
        $ownerName = post_value('owner_name');
        $email = strtolower(post_value('email'));
        $whatsapp = preg_replace('/\D/', '', post_value('whatsapp'));
        $password = isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : '';

        if (!valid_text($storeName, 2, 120) || !valid_text($ownerName, 2, 120)) {
            $error = 'Informe o nome da loja e o seu nome, com 2 a 120 caracteres cada.';
        } elseif (strlen($email) > 190 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Informe um e-mail válido.';
        } elseif (!valid_whatsapp($whatsapp)) {
            $error = 'Informe um WhatsApp válido com código do país e DDD.';
        } elseif (!valid_password($password)) {
            $error = 'Use uma senha de pelo menos 8 caracteres, sem espaços nas pontas; se ela for muito longa, reduza seu tamanho.';
        } elseif (!reset_rate_allow('register-ip:' . input_value($_SERVER, 'REMOTE_ADDR', 'unknown'), 10)) {
            $error = 'Muitas tentativas. Aguarde até uma hora para cadastrar outra conta.';
        } else {
            $exists = db()->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
            $exists->execute(array($email));
            if ($exists->fetch()) {
                $error = 'Este e-mail já está cadastrado. Tente entrar no painel.';
            } else {
                $slug = unique_slug($storeName);
                $pdo = db();
                try {
                    $pdo->beginTransaction();
                    $tenantStmt = $pdo->prepare('INSERT INTO tenants (name, slug, owner_name, whatsapp) VALUES (?, ?, ?, ?)');
                    $tenantStmt->execute(array($storeName, $slug, $ownerName, $whatsapp !== '' ? $whatsapp : null));
                    $tenantId = (int) $pdo->lastInsertId();
                    $userStmt = $pdo->prepare('INSERT INTO users (tenant_id, name, email, password_hash, role) VALUES (?, ?, ?, ?, "owner")');
                    $userStmt->execute(array($tenantId, $ownerName, $email, password_hash($password, PASSWORD_DEFAULT)));
                    $userId = (int) $pdo->lastInsertId();
                    $pdo->commit();
                    login_user($userId);
                    redirect_to('dashboard.php');
                } catch (Exception $exception) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $error = 'Não foi possível criar a conta agora. Verifique a configuração do banco.';
                }
            }
        }
    }
}

$page_title = 'Criar loja';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-page">
    <section class="auth-showcase">
        <a class="auth-brand" href="<?php echo e(app_url('index.php')); ?>">
            <span class="brand-mark">O</span>
            <span><strong>Olho na</strong><small>Minha Loja</small></span>
        </a>
        <h1>Comece a olhar para os números certos.</h1>
        <p>Crie sua conta, cadastre os produtos e compartilhe o link exclusivo da sua loja. O painel organiza os sinais mais importantes do seu negócio.</p>
        <div class="auth-points">
            <div class="auth-point"><strong>1 loja</strong><span>por conta</span></div>
            <div class="auth-point"><strong>2 tipos</strong><span>estoque próprio ou afiliado</span></div>
            <div class="auth-point"><strong>1 painel</strong><span>com seus dados separados</span></div>
        </div>
    </section>
    <section class="auth-panel">
        <div class="auth-card">
            <span class="eyebrow">PRIMEIRO PASSO</span>
            <h2>Crie sua loja</h2>
            <p>Cadastre seus dados para começar. Você poderá ajustar os produtos depois.</p>
            <?php if ($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>
            <form method="post" action="<?php echo e(app_url('register.php')); ?>">
                <input type="hidden" name="_csrf" value="<?php echo e(csrf_token()); ?>">
                <div class="field"><label for="store_name">Nome da loja</label><input id="store_name" name="store_name" maxlength="120" type="text" placeholder="Ex.: Loja da Ana" required></div>
                <div class="field"><label for="owner_name">Seu nome</label><input id="owner_name" name="owner_name" maxlength="120" type="text" autocomplete="name" required></div>
                <div class="field"><label for="email">E-mail de acesso</label><input id="email" name="email" maxlength="190" type="email" autocomplete="email" required></div>
                <div class="field"><label for="whatsapp">WhatsApp da loja <span style="font-weight:400;color:#8993a8">(opcional)</span></label><input id="whatsapp" name="whatsapp" maxlength="25" type="text" placeholder="5511999999999"><small>Use o código do país e DDD para os pedidos abrirem corretamente.</small></div>
                <div class="field"><label for="password">Senha</label><input id="password" name="password" type="password" minlength="8" autocomplete="new-password" required><small>Mínimo de 8 caracteres.</small></div>
                <button class="button button-primary button-block" type="submit">Criar minha conta</button>
            </form>
            <div class="auth-footer">Já tem uma conta? <a href="<?php echo e(app_url('index.php')); ?>">Voltar para o login</a></div>
        </div>
    </section>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
