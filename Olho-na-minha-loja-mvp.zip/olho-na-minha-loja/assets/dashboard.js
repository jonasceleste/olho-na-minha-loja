(function () {
  function svgElement(name, attrs) {
    var element = document.createElementNS('http://www.w3.org/2000/svg', name);
    Object.keys(attrs).forEach(function (key) { element.setAttribute(key, attrs[key]); });
    return element;
  }

  function text(svg, x, y, value, attrs) {
    var node = svgElement('text', Object.assign({ x: x, y: y }, attrs || {}));
    node.textContent = value;
    svg.appendChild(node);
  }

  function empty(container, message) {
    container.innerHTML = '<div class="chart-empty">' + message + '</div>';
  }

  function drawLineChart(container, points) {
    if (!points.length || points.every(function (item) { return Number(item.value) === 0; })) {
      empty(container, 'Ainda não há vendas confirmadas para desenhar este período.');
      return;
    }
    var width = 760, height = 250, pad = { top: 20, right: 20, bottom: 42, left: 100 };
    var max = Math.max.apply(null, points.map(function (item) { return Number(item.value); })) || 1;
    var innerW = width - pad.left - pad.right, innerH = height - pad.top - pad.bottom;
    var svg = svgElement('svg', { viewBox: '0 0 ' + width + ' ' + height, role: 'img', 'aria-label': 'Receita por dia' });
    var grid = [0, 0.5, 1];
    grid.forEach(function (ratio) {
      var y = pad.top + innerH - (innerH * ratio);
      svg.appendChild(svgElement('line', { x1: pad.left, y1: y, x2: width - pad.right, y2: y, class: 'chart-grid' }));
      text(svg, pad.left - 10, y + 4, 'R$ ' + Math.round(max * ratio), { class: 'chart-axis-label', 'text-anchor': 'end' });
    });
    var coords = points.map(function (item, index) {
      var x = pad.left + (innerW * (points.length === 1 ? 0.5 : index / (points.length - 1)));
      var y = pad.top + innerH - (innerH * (Number(item.value) / max));
      return { x: x, y: y, label: item.label, value: Number(item.value) };
    });
    svg.appendChild(svgElement('polyline', { points: coords.map(function (point) { return point.x + ',' + point.y; }).join(' '), class: 'chart-line' }));
    coords.forEach(function (point) {
      svg.appendChild(svgElement('circle', { cx: point.x, cy: point.y, r: 4, class: 'chart-point' }));
      text(svg, point.x, height - 14, point.label, { class: 'chart-axis-label', 'text-anchor': 'middle' });
    });
    container.innerHTML = '';
    container.appendChild(svg);
  }

  function drawBars(container, points) {
    if (!points.length || points.every(function (item) { return Number(item.value) === 0; })) {
      empty(container, 'Os cliques aparecerão aqui quando sua loja começar a receber visitas.');
      return;
    }
    var max = Math.max.apply(null, points.map(function (item) { return Number(item.value); })) || 1;
    var list = document.createElement('div');
    list.className = 'bar-list';
    points.forEach(function (item) {
      var percent = Math.max(0, Math.min(100, Math.round((Number(item.value) / max) * 100)));
      var row = document.createElement('div'); row.className = 'bar-row';
      var meta = document.createElement('div'); meta.className = 'bar-meta';
      var label = document.createElement('span'); label.textContent = item.label; label.title = item.label;
      var value = document.createElement('strong'); value.textContent = item.value;
      var track = document.createElement('div'); track.className = 'bar-track';
      var bar = document.createElement('i'); bar.style.width = percent + '%';
      meta.appendChild(label); meta.appendChild(value); track.appendChild(bar);
      row.appendChild(meta); row.appendChild(track); list.appendChild(row);
    });
    container.replaceChildren(list);
  }

  var dataNode = document.getElementById('dashboard-data');
  if (!dataNode) return;
  var data = JSON.parse(dataNode.textContent || '{}');
  var salesChart = document.getElementById('sales-chart');
  var clicksChart = document.getElementById('clicks-chart');
  if (salesChart) drawLineChart(salesChart, data.sales || []);
  if (clicksChart) drawBars(clicksChart, data.clicks || []);
}());
