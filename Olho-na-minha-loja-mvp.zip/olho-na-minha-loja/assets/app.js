(function () {
  var buttons = document.querySelectorAll('[data-confirm]');
  Array.prototype.forEach.call(buttons, function (button) {
    button.addEventListener('click', function (event) {
      var message = button.getAttribute('data-confirm') || 'Deseja continuar?';
      if (!window.confirm(message)) {
        event.preventDefault();
      }
    });
  });

  var flashMessages = document.querySelectorAll('.alert-success');
  Array.prototype.forEach.call(flashMessages, function (message) {
    window.setTimeout(function () {
      message.classList.add('is-hidden');
    }, 6500);
  });
}());
