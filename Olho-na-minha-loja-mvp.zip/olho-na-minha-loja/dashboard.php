<?php
require __DIR__ . '/includes/bootstrap.php';
require_login();

$page_title = 'Visão geral';
$tenant = current_tenant();
$tenantId = tenant_id();

function dashboard_scalar($sql, $params)
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchColumn();
}

$views = (int) dashboard_scalar('SELECT COUNT(*) FROM page_views WHERE tenant_id = ?', array($tenantId));
$clicks = (int) dashboard_scalar('SELECT COUNT(*) FROM click_events WHERE tenant_id = ?', array($tenantId));
$orders = (int) dashboard_scalar('SELECT COUNT(*) FROM orders WHERE tenant_id = ? AND status = "paid"', array($tenantId));
$revenue = (float) dashboard_scalar('SELECT COALESCE(SUM(revenue), 0) FROM orders WHERE tenant_id = ? AND status = "paid"', array($tenantId));
$profit = (float) dashboard_scalar('SELECT COALESCE(SUM(profit), 0) FROM orders WHERE tenant_id = ? AND status = "paid"', array($tenantId));
$conversion = $clicks > 0 ? ($orders / $clicks) * 100 : 0;
$clickRate = $views > 0 ? ($clicks / $views) * 100 : 0;

$startDate = date('Y-m-d', strtotime('-6 days'));
$salesByDay = array();
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime('-' . $i . ' days'));
    $salesByDay[$date] = array('label' => date('d/m', strtotime($date)), 'value' => 0);
}

$salesStmt = db()->prepare('SELECT DATE(created_at) AS day, SUM(revenue) AS total FROM orders WHERE tenant_id = ? AND status = "paid" AND created_at >= ? GROUP BY DATE(created_at) ORDER BY day ASC');
$salesStmt->execute(array($tenantId, $startDate . ' 00:00:00'));
foreach ($salesStmt->fetchAll() as $row) {
    if (isset($salesByDay[$row['day']])) {
        $salesByDay[$row['day']]['value'] = (float) $row['total'];
    }
}

$clicksStmt = db()->prepare('SELECT p.name, COUNT(c.id) AS total FROM click_events c INNER JOIN products p ON p.id = c.product_id WHERE c.tenant_id = ? GROUP BY c.product_id, p.name ORDER BY total DESC LIMIT 5');
$clicksStmt->execute(array($tenantId));
$clicksByProduct = array();
foreach ($clicksStmt->fetchAll() as $row) {
    $clicksByProduct[] = array('label' => $row['name'], 'value' => (int) $row['total']);
}

$productsStmt = db()->prepare('SELECT p.*, (SELECT COUNT(*) FROM click_events c WHERE c.product_id = p.id AND c.tenant_id = p.tenant_id) AS clicks FROM products p WHERE p.tenant_id = ? AND p.status <> "archived" ORDER BY p.created_at DESC LIMIT 6');
$productsStmt->execute(array($tenantId));
$products = $productsStmt->fetchAll();

$suggestions = array();
if ($views === 0 && $clicks === 0) {
    $suggestions[] = array('icon' => '✦', 'title' => 'Comece divulgando sua loja', 'text' => 'Compartilhe seu link exclusivo no WhatsApp, Instagram e TikTok para gerar as primeiras visitas.');
}
if ($views > 0 && $clicks === 0) {
    $suggestions[] = array('icon' => '↗', 'title' => 'Melhore a chamada para ação', 'text' => 'Sua loja recebeu visitas, mas ainda não registrou cliques. Destaque preço, benefício e botão de oferta.');
}
if ($clicks > 0 && $orders === 0) {
    $suggestions[] = array('icon' => '!', 'title' => 'Investigue os cliques sem venda', 'text' => 'Confira se todas as vendas foram registradas. Depois, revise preço, descrição e atendimento dos produtos mais clicados.');
}
if ($views > 0 && $clicks > 0 && $clickRate < 2) {
    $suggestions[] = array('icon' => '◌', 'title' => 'Aumente a conversão', 'text' => 'Há menos de 2 cliques para cada 100 visualizações. Teste outra imagem principal e uma oferta mais clara.');
}
if ($orders > 0 && $revenue > 0 && (($profit / $revenue) * 100) < 15) {
    $suggestions[] = array('icon' => 'R$', 'title' => 'Proteja sua margem', 'text' => 'Seu lucro está abaixo de 15% da receita registrada. Revise custos, taxas e preço.');
}
if (empty($suggestions)) {
    $suggestions[] = array('icon' => '✓', 'title' => 'Tudo em ordem por enquanto', 'text' => 'Continue acompanhando o painel e compare os próximos 7 dias com este período.');
}

$dashboardData = array(
    'sales' => array_values($salesByDay),
    'clicks' => $clicksByProduct,
);
$page_script = 'assets/dashboard.js';
require __DIR__ . '/includes/header.php';
?>
<section class="panel" style="margin-bottom:18px;padding:17px 20px;">
    <div class="panel-header" style="align-items:center;margin-bottom:0;">
        <div><span class="eyebrow">SEU LINK EXCLUSIVO</span><div class="link-box"><code id="store-link"><?php echo e(store_url($tenant['slug'])); ?></code><button class="copy-button" type="button" onclick="copyStoreLink()">Copiar</button></div></div>
        <a class="button button-secondary button-small" href="<?php echo e(store_url($tenant['slug'])); ?>" target="_blank" rel="noopener">Ver loja ↗</a>
    </div>
</section>

<section class="grid kpi-grid">
    <article class="kpi-card"><div class="kpi-icon blue">◉</div><span class="kpi-label">Visualizações</span><strong class="kpi-value"><?php echo number_format($views, 0, ',', '.'); ?></strong><span class="kpi-note">visitas na loja</span></article>
    <article class="kpi-card"><div class="kpi-icon purple">↗</div><span class="kpi-label">Cliques</span><strong class="kpi-value"><?php echo number_format($clicks, 0, ',', '.'); ?></strong><span class="kpi-note">nos botões de oferta</span></article>
    <article class="kpi-card"><div class="kpi-icon orange">▣</div><span class="kpi-label">Vendas</span><strong class="kpi-value"><?php echo number_format($orders, 0, ',', '.'); ?></strong><span class="kpi-note">confirmadas no painel</span></article>
    <article class="kpi-card"><div class="kpi-icon green">R$</div><span class="kpi-label">Receita</span><strong class="kpi-value"><?php echo e(money($revenue)); ?></strong><span class="kpi-note">vendas confirmadas</span></article>
    <article class="kpi-card"><div class="kpi-icon blue">✦</div><span class="kpi-label">Lucro</span><strong class="kpi-value"><?php echo e(money($profit)); ?></strong><span class="kpi-note">margem <?php echo $revenue > 0 ? e(number_format(($profit / $revenue) * 100, 1, ',', '.')) . '%' : '—'; ?></span></article>
</section>

<section class="grid dashboard-grid">
    <article class="panel">
        <div class="panel-header"><div><h2>Receita nos últimos 7 dias</h2><p>Vendas confirmadas registradas manualmente no painel.</p></div><span class="badge badge-blue">7 dias</span></div>
        <div id="sales-chart" class="chart"></div>
    </article>
    <article class="panel">
        <div class="panel-header"><div><h2>Cliques por produto</h2><p>Onde o interesse está concentrado.</p></div><a class="panel-link" href="<?php echo e(app_url('produtos.php')); ?>">Ver produtos</a></div>
        <div id="clicks-chart" class="chart"></div>
    </article>
</section>

<section class="grid dashboard-grid">
    <article class="panel">
        <div class="panel-header"><div><h2>Visão dos resultados</h2><p>Contagens acumuladas desde o início da loja.</p></div><span class="badge badge-green"><?php echo e(number_format($conversion, 1, ',', '.')); ?>% vendas/cliques</span></div>
        <div class="funnel">
            <?php $funnelMax = max($views, 1); ?>
            <div class="funnel-row"><label>Visualizações</label><div class="funnel-track"><i style="width:<?php echo $views > 0 ? '100' : '0'; ?>%"></i></div><strong><?php echo number_format($views, 0, ',', '.'); ?></strong></div>
            <div class="funnel-row"><label>Cliques</label><div class="funnel-track"><i style="width:<?php echo e(min(100, ($clicks / $funnelMax) * 100)); ?>%;background:#735be1"></i></div><strong><?php echo number_format($clicks, 0, ',', '.'); ?></strong></div>
            <div class="funnel-row"><label>Vendas</label><div class="funnel-track"><i style="width:<?php echo e(min(100, ($orders / $funnelMax) * 100)); ?>%;background:#1aa879"></i></div><strong><?php echo number_format($orders, 0, ',', '.'); ?></strong></div>
        </div>
        <div class="notice" style="margin-top:20px;">Para produtos afiliados, o sistema registra cliques. Comissão e venda precisam ser lançadas manualmente, pois não há integração automática com as plataformas. As vendas manuais não são vinculadas aos cliques: a proporção acima não representa conversão comprovada. Visualizações e cliques podem incluir repetições.</div>
    </article>
    <article class="panel">
        <div class="panel-header"><div><h2>Onde melhorar</h2><p>Leituras automáticas dos seus indicadores.</p></div><span class="badge badge-orange">orientações</span></div>
        <div class="suggestions">
            <?php foreach ($suggestions as $suggestion): ?><div class="suggestion"><span class="suggestion-icon"><?php echo e($suggestion['icon']); ?></span><div><strong><?php echo e($suggestion['title']); ?></strong><p><?php echo e($suggestion['text']); ?></p></div></div><?php endforeach; ?>
        </div>
    </article>
</section>

<section class="panel">
    <div class="panel-header"><div><h2>Produtos recentes</h2><p>Os produtos ficam separados somente dentro da sua loja.</p></div><a class="panel-link" href="<?php echo e(app_url('produtos.php')); ?>">Gerenciar produtos →</a></div>
    <?php if (!$products): ?>
        <div class="empty-state"><h3>Seu painel está pronto para começar.</h3><p>Cadastre o primeiro produto para criar sua loja pública e começar a acompanhar cliques.</p><a class="button button-primary" href="<?php echo e(app_url('produtos.php')); ?>">Cadastrar primeiro produto</a></div>
    <?php else: ?>
        <div class="table-wrap"><table><thead><tr><th>Produto</th><th>Tipo</th><th>Preço</th><th>Cliques</th><th>Situação</th></tr></thead><tbody>
        <?php foreach ($products as $product): ?>
            <tr><td><div class="product-cell"><?php if (!empty($product['image_url'])): ?><img class="product-thumb" src="<?php echo e($product['image_url']); ?>" alt=""><?php else: ?><span class="product-thumb"></span><?php endif; ?><div><strong><?php echo e($product['name']); ?></strong><small><?php echo e($product['category'] ?: 'Sem categoria'); ?></small></div></div></td><td><span class="badge <?php echo $product['sale_type'] === 'affiliate' ? 'badge-blue' : 'badge-green'; ?>"><?php echo e(sale_type_label($product['sale_type'])); ?></span></td><td><?php echo e(money($product['price'])); ?></td><td><?php echo number_format((int) $product['clicks'], 0, ',', '.'); ?></td><td><span class="badge <?php echo $product['status'] === 'published' ? 'badge-green' : 'badge-gray'; ?>"><?php echo $product['status'] === 'published' ? 'Publicado' : 'Rascunho'; ?></span></td></tr>
        <?php endforeach; ?>
        </tbody></table></div>
    <?php endif; ?>
</section>

<script id="dashboard-data" type="application/json"><?php echo json_encode($dashboardData, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?></script>
<script>
async function copyStoreLink() {
    var value = document.getElementById('store-link').textContent;
    var button = document.querySelector('.copy-button');
    try {
        if (!navigator.clipboard) throw new Error('Clipboard unavailable');
        await navigator.clipboard.writeText(value);
        button.textContent = 'Copiado!';
    } catch (error) {
        window.prompt('Copie o link da sua loja:', value);
        button.textContent = 'Copiar';
    }
    window.setTimeout(function () { button.textContent = 'Copiar'; }, 1800);
}

</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
