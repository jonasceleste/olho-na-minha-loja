<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
error_reporting(E_ALL);
$root = dirname(__DIR__);
foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root)) as $file) {
    if ($file->getExtension() === 'php') { token_get_all(file_get_contents($file->getPathname()), TOKEN_PARSE); }
}
require $root . '/includes/functions.php';
require $root . '/includes/orders.php';
require $root . '/includes/password_reset.php';
class TestPDO extends PDO {
    public function prepare(string $query, array $options = []): PDOStatement|false {
        $query = str_replace(' FOR UPDATE', '', $query);
        $query = str_replace('INSERT IGNORE', 'INSERT OR IGNORE', $query);
        return parent::prepare($query, $options);
    }
}
$pdo = new TestPDO('sqlite::memory:', null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
function db() { global $pdo; return $pdo; }
$pdo->exec('CREATE TABLE tenants(id INTEGER PRIMARY KEY,status TEXT); CREATE TABLE users(id INTEGER PRIMARY KEY,tenant_id INTEGER,status TEXT,password_hash TEXT); CREATE TABLE products(id INTEGER PRIMARY KEY,tenant_id INTEGER,status TEXT,sale_type TEXT,stock_qty INTEGER,price NUMERIC); CREATE TABLE orders(id INTEGER PRIMARY KEY,tenant_id INTEGER,order_type TEXT,status TEXT,customer_name TEXT,notes TEXT,revenue NUMERIC,cost_total NUMERIC,profit NUMERIC); CREATE TABLE order_items(id INTEGER PRIMARY KEY,order_id INTEGER,product_id INTEGER,quantity INTEGER,unit_price NUMERIC); CREATE TABLE password_resets(user_id INTEGER PRIMARY KEY,token_hash TEXT,expires_at INTEGER); CREATE TABLE password_reset_limits(bucket_key TEXT PRIMARY KEY,window_start INTEGER,attempts INTEGER);');
$tests=0;
function check($condition,$label) { global $tests; if (!$condition) { throw new Exception('FAIL '.$label); } $tests++; echo "PASS $label\n"; }
function rejects($fn,$label) { try { $fn(); } catch (DomainException $e) { check(true,$label); return; } check(false,$label); }
check(to_float('1.234,56')===1234.56,'BRL grouped decimal');
check(to_float('1234.56')===1234.56,'dot decimal');
foreach(['abc','1e3','-1','12.345','1,2,3','10000000000','1.234.56'] as $v) { check(to_float($v)===null,'reject invalid amount '.$v); }
check(slugify('Loja São João') === 'loja-sao-joao', 'Portuguese accents in store slug');
check(valid_text('João',4,4),'Unicode character length');
check(!valid_password('curta'),'short password');
check(!valid_password(str_repeat('á',40)),'bcrypt byte limit');
check(valid_password('SenhaSegura123!'),'valid password');
check(!valid_http_url("https://example.com/\r\nX-Test: x"),'reject header injection URL');
check(!valid_http_url('javascript:alert(1)'),'reject unsafe scheme');
check(!valid_http_url('https://user:pass@example.com'),'reject URL credentials');
check(valid_whatsapp('5511999999999'),'WhatsApp with country code');
check(!valid_whatsapp('12'),'reject short phone');
check(positive_integer('1.5')===null,'reject fractional quantity');
$pdo->exec("INSERT INTO tenants VALUES(1,'active'),(2,'active'); INSERT INTO products VALUES(1,1,'published','own',2,100),(2,2,'published','own',10,50),(3,1,'published','affiliate',0,999);");
$id=create_order(1,1,1,100,40,'paid','Cliente','');
check((int)$pdo->query('SELECT stock_qty FROM products WHERE id=1')->fetchColumn()===1,'paid sale decrements stock');
check((float)$pdo->query('SELECT profit FROM orders WHERE id=1')->fetchColumn()===60.0,'profit calculated');
rejects(fn()=>create_order(1,1,2,200,80,'paid','',''),'insufficient stock rejected');
check((int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn()===1,'failed sale rolls back order');
rejects(fn()=>create_order(1,2,1,50,20,'paid','',''),'cross-tenant product rejected');
$pending=create_order(1,1,1,100,40,'pending','','');
check((int)$pdo->query('SELECT stock_qty FROM products WHERE id=1')->fetchColumn()===1,'pending order does not deduct');
change_order_status(1,$pending,'paid');
check((int)$pdo->query('SELECT stock_qty FROM products WHERE id=1')->fetchColumn()===0,'confirm pending deducts');
change_order_status(1,$pending,'paid');
check((int)$pdo->query('SELECT stock_qty FROM products WHERE id=1')->fetchColumn()===0,'repeated confirmation idempotent');
rejects(fn()=>create_order(1,1,1,100,40,'paid','',''),'zero stock cannot sell');
change_order_status(1,$pending,'cancelled');
change_order_status(1,$pending,'cancelled');
check((int)$pdo->query('SELECT stock_qty FROM products WHERE id=1')->fetchColumn()===1,'cancellation restores stock once');
rejects(fn()=>change_order_status(2,$id,'cancelled'),'cross-tenant order update rejected');
rejects(fn()=>change_order_status(1,$pending,'paid'),'cancelled order cannot reopen');
$affiliate=create_order(1,3,2,20,5,'paid','','');
check((float)$pdo->query('SELECT revenue FROM orders WHERE id='.$affiliate)->fetchColumn()===20.0,'affiliate revenue uses commission');
check((float)$pdo->query('SELECT unit_price FROM order_items WHERE order_id='.$affiliate)->fetchColumn()===10.0,'unit amount based on actual received value');
check(reset_rate_allow('test',2),'rate first allowed');check(reset_rate_allow('test',2),'rate second allowed');check(!reset_rate_allow('test',2),'rate third rejected');
$pdo->exec('UPDATE password_reset_limits SET window_start=0');check(reset_rate_allow('test',2),'rate window expires');
$old=password_hash('SenhaAntiga123',PASSWORD_DEFAULT);
$s=$pdo->prepare('INSERT INTO users VALUES(1,1,\'active\',?)');$s->execute([$old]);
$token=bin2hex(random_bytes(32));$s=$pdo->prepare('INSERT INTO password_resets VALUES(1,?,?)');$s->execute([hash('sha256',$token),time()+1800]);
check(!complete_password_reset(str_repeat('f',64),'NovaSenha123'),'wrong token rejected');
check(!complete_password_reset($token,'123'),'invalid new password rejected');
check(complete_password_reset($token,'NovaSenha123'),'reset valid token');
check(password_verify('NovaSenha123',$pdo->query('SELECT password_hash FROM users WHERE id=1')->fetchColumn()),'new password stored hashed');
check(!complete_password_reset($token,'OutraSenha123'),'used token rejected');
$s->execute([hash('sha256',$token),time()-1]);check(!complete_password_reset($token,'OutraSenha123'),'expired token rejected');
$pdo->exec('UPDATE password_resets SET expires_at='.(time()+1800));$pdo->exec("UPDATE tenants SET status='blocked' WHERE id=1");
check(!complete_password_reset($token,'OutraSenha123'),'blocked tenant reset rejected');
echo "TOTAL $tests assertions passed\n";
