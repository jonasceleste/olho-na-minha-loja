<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/password_reset.php';
header('Cache-Control: no-store');
$error = ''; $message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(post_value('email'));
    if (!verify_csrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) {
        $error = 'A sessão expirou. Atualize a página e tente novamente.';
    } elseif (strlen($email) > 190 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Informe um e-mail válido.';
    } else {
        try {
            request_password_reset($email, isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown');
        } catch (Throwable $e) {
            error_log('Olho na Minha Loja: falha na recuperacao. Verifique migracao SQL, config.mail.php e transporte de e-mail.');
        }
        $message = 'Se este e-mail estiver cadastrado e o envio estiver disponível, você receberá um link válido por 30 minutos. Confira também o spam. Se não chegar, aguarde antes de tentar novamente ou fale com o responsável pela loja.';
    }
}
$page_title = 'Recuperar senha';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-panel" style="min-height:100vh"><div class="auth-card">
<span class="eyebrow">OLHO NA MINHA LOJA</span><h2>Esqueci minha senha</h2>
<p>Informe o e-mail usado na criação da sua conta.</p>
<?php if ($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>
<?php if ($message): ?><div class="notice" role="status"><?php echo e($message); ?></div><?php endif; ?>
<form method="post" action="<?php echo e(app_url('esqueci-senha.php')); ?>">
<input type="hidden" name="_csrf" value="<?php echo e(csrf_token()); ?>">
<div class="field"><label for="email">E-mail cadastrado</label><input id="email" name="email" maxlength="190" type="email" autocomplete="email" required></div>
<button class="button button-primary button-block">Enviar link de recuperação</button>
</form><div class="auth-footer"><a href="<?php echo e(app_url('index.php')); ?>">Voltar para o login</a></div>
</div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
