<?php

/*
 * Copie este arquivo para cada ambiente e preencha os dados do banco criado
 * no cPanel. Nunca publique a senha do banco em um repositório.
 */
return array(
    'app' => array(
        'name' => 'Olho na Minha Loja',
        'base_url' => 'https://megavitrineonline.top/olho/',
        'timezone' => 'America/Cuiaba',
        'session_name' => 'olho_na_minha_loja',
    ),
    'db' => array(
        'host' => 'localhost',
        'name' => 'jonass91_olho',
        'user' => 'jonass91_olho',
        'pass' => 'ALTERE_ESTA_SENHA',
        'charset' => 'utf8mb4',
    ),
);
