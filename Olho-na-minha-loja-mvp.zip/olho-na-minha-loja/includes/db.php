<?php

function db()
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    global $config;
    $dsn = 'mysql:host=' . $config['db']['host']
        . ';dbname=' . $config['db']['name']
        . ';charset=' . $config['db']['charset'];

    $pdo = new PDO($dsn, $config['db']['user'], $config['db']['pass'], array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ));

    // Keep TIMESTAMP/DATE reports aligned with the application's timezone.
    $pdo->exec("SET time_zone = " . $pdo->quote(date('P')));
    return $pdo;
}
