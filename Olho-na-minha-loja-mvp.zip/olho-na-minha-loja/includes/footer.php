    </main>
</div>
<script src="<?php echo e(app_url('assets/app.js')); ?>"></script>
<?php if (!empty($page_script)): ?><script src="<?php echo e(app_url($page_script)); ?>"></script><?php endif; ?>
</body>
</html>
