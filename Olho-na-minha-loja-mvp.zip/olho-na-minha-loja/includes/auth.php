<?php

function login_user($userId)
{
    session_regenerate_id(true);
    $stmt = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
    $stmt->execute(array((int) $userId));
    $_SESSION['auth_password_stamp'] = hash('sha256', (string) $stmt->fetchColumn());
    $_SESSION['user_id'] = (int) $userId;
}

function logout_user()
{
    $_SESSION = array();
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}
