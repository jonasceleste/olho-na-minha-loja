<?php
// Hashes, timestamps UTC e limites persistentes; nenhum token em logs.
function reset_token_valid($token)
{
    return is_string($token) && preg_match('/\A[a-f0-9]{64}\z/D', $token) === 1;
}

function reset_rate_allow($key, $max)
{
    $pdo = db();
    $now = time();
    $key = hash('sha256', $key);
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare('INSERT IGNORE INTO password_reset_limits (bucket_key, window_start, attempts) VALUES (?, ?, 0)');
        $s->execute(array($key, $now));
        $s = $pdo->prepare('SELECT window_start, attempts FROM password_reset_limits WHERE bucket_key = ? FOR UPDATE');
        $s->execute(array($key));
        $row = $s->fetch();
        $start = (int) $row['window_start'];
        $count = (int) $row['attempts'];
        if ($start <= $now - 3600) { $start = $now; $count = 0; }
        $allowed = $count < $max;
        $s = $pdo->prepare('UPDATE password_reset_limits SET window_start = ?, attempts = ? WHERE bucket_key = ?');
        $s->execute(array($start, min($count + 1, $max), $key));
        $pdo->commit();
        return $allowed;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        throw $e;
    }
}

function request_password_reset($email, $ip)
{
    db()->exec('DELETE FROM password_reset_limits WHERE window_start < ' . (time() - 86400));
    db()->exec('DELETE FROM password_resets WHERE expires_at < ' . time());
    if (!reset_rate_allow('ip:' . $ip, 10)) { return; }
    if (!reset_rate_allow('email:' . $email, 3)) { return; }
    $mailFile = __DIR__ . '/../config.mail.php';
    $mail = is_file($mailFile) ? require $mailFile : array();
    $from = isset($mail['from']) ? $mail['from'] : '';
    $base = app_url();
    if (empty($mail['enabled']) || !filter_var($from, FILTER_VALIDATE_EMAIL)
        || preg_match('/[\r\n]/', $from) || !filter_var($base, FILTER_VALIDATE_URL)
        || parse_url($base, PHP_URL_SCHEME) !== 'https' || !function_exists('mail')) {
        throw new RuntimeException('Mail configuration unavailable');
    }
    $s = db()->prepare('SELECT u.id, u.email FROM users u INNER JOIN tenants t ON t.id = u.tenant_id WHERE u.email = ? AND u.status = "active" AND t.status = "active" LIMIT 1');
    $s->execute(array($email));
    $user = $s->fetch();
    if (!$user || !filter_var($user['email'], FILTER_VALIDATE_EMAIL)) { return; }
    $token = bin2hex(random_bytes(32));
    $hash = hash('sha256', $token);
    $s = db()->prepare('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE token_hash = VALUES(token_hash), expires_at = VALUES(expires_at)');
    $s->execute(array($user['id'], $hash, time() + 1800));
    $url = app_url('redefinir-senha.php?token=' . $token);
    $body = "Olho na Minha Loja\r\n\r\nPara criar uma nova senha, abra o link abaixo.\r\nVálido por 30 minutos e para um único uso.\r\n\r\n" . $url . "\r\n\r\nSe você não pediu esta alteração, ignore este e-mail.\r\nSua senha permanece a mesma até a confirmação.\r\n";
    $ok = @mail($user['email'], 'Redefinir senha - Olho na Minha Loja', $body,
        'From: Olho na Minha Loja <' . $from . ">\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8");
    if (!$ok) {
        $s = db()->prepare('DELETE FROM password_resets WHERE user_id = ? AND token_hash = ?');
        $s->execute(array($user['id'], $hash));
        throw new RuntimeException('Mail transport failed');
    }
}

function complete_password_reset($token, $password)
{
    if (!reset_token_valid($token) || !valid_password($password)) { return false; }
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare('SELECT user_id, expires_at FROM password_resets WHERE token_hash = ? FOR UPDATE');
        $s->execute(array(hash('sha256', $token)));
        $row = $s->fetch();
        if (!$row || (int) $row['expires_at'] <= time()) { $pdo->rollBack(); return false; }
        $s = $pdo->prepare('SELECT u.id FROM users u INNER JOIN tenants t ON t.id = u.tenant_id WHERE u.id = ? AND u.status = "active" AND t.status = "active"');
        $s->execute(array($row['user_id']));
        if (!$s->fetch()) { $pdo->rollBack(); return false; }
        $s = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
        $s->execute(array(password_hash($password, PASSWORD_DEFAULT), $row['user_id']));
        $s = $pdo->prepare('DELETE FROM password_resets WHERE user_id = ?');
        $s->execute(array($row['user_id']));
        $pdo->commit();
        return true;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        throw $e;
    }
}
