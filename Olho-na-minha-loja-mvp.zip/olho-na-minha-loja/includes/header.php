<?php
$page_title = isset($page_title) ? $page_title : app_config('app', 'name');
$user = current_user();
?><!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0b132b">
    <title><?php echo e($page_title); ?> · <?php echo e(app_config('app', 'name')); ?></title>
    <link rel="stylesheet" href="<?php echo e(app_url('assets/app.css')); ?>">
</head>
<body>
<div class="app-shell">
    <?php if ($user): ?>
        <aside class="sidebar">
            <a class="brand" href="<?php echo e(app_url('dashboard.php')); ?>">
                <span class="brand-mark">O</span>
                <span>
                    <strong>Olho na</strong>
                    <small>Minha Loja</small>
                </span>
            </a>
            <div class="sidebar-store">
                <span class="eyebrow">LOJA ATIVA</span>
                <strong><?php echo e($user['tenant_name']); ?></strong>
                <a href="<?php echo e(store_url($user['tenant_slug'])); ?>" target="_blank" rel="noopener">Abrir loja ↗</a>
            </div>
            <nav class="nav-links" aria-label="Navegação principal">
                <a class="<?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>" href="<?php echo e(app_url('dashboard.php')); ?>"><span>◈</span> Visão geral</a>
                <a class="<?php echo basename($_SERVER['PHP_SELF']) === 'produtos.php' ? 'active' : ''; ?>" href="<?php echo e(app_url('produtos.php')); ?>"><span>▣</span> Produtos</a>
                <a class="<?php echo basename($_SERVER['PHP_SELF']) === 'pedidos.php' ? 'active' : ''; ?>" href="<?php echo e(app_url('pedidos.php')); ?>"><span>↗</span> Vendas e pedidos</a>
                <a class="<?php echo basename($_SERVER['PHP_SELF']) === 'configuracoes.php' ? 'active' : ''; ?>" href="<?php echo e(app_url('configuracoes.php')); ?>"><span>⚙</span> Configurações</a>
            </nav>
            <div class="sidebar-bottom">
                <div class="account-chip"><span class="avatar"><?php echo e(preg_replace('/^(.).*$/us', '$1', $user['name'])); ?></span><span><strong><?php echo e($user['name']); ?></strong><small><?php echo e($user['email']); ?></small></span></div>
                <form method="post" action="<?php echo e(app_url('logout.php')); ?>"><input type="hidden" name="_csrf" value="<?php echo e(csrf_token()); ?>"><button class="logout-link" type="submit">Sair</button></form>
            </div>
        </aside>
    <?php endif; ?>
    <main class="main-content<?php echo $user ? '' : ' full-width'; ?>">
        <?php if ($user): ?>
            <header class="topbar">
                <div>
                    <span class="eyebrow">PAINEL DA LOJA</span>
                    <h1><?php echo e($page_title); ?></h1>
                </div>
                <div class="topbar-actions">
                    <span class="status-dot"><i></i> Sistema ativo</span>
                    <a class="button button-primary button-small" href="<?php echo e(app_url('produtos.php')); ?>">+ Adicionar oferta</a>
                </div>
            </header>
        <?php endif; ?>
        <?php if ($message = flash('success')): ?><div class="alert alert-success"><?php echo e($message); ?></div><?php endif; ?>
        <?php if ($message = flash('error')): ?><div class="alert alert-error"><?php echo e($message); ?></div><?php endif; ?>
