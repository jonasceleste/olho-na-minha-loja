<?php
function create_order($tenantId, $productId, $quantity, $revenue, $costTotal, $status, $customerName, $notes)
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare('SELECT * FROM products WHERE id = ? AND tenant_id = ? AND status <> "archived" FOR UPDATE');
        $s->execute(array($productId, $tenantId));
        $product = $s->fetch();
        if (!$product) { throw new DomainException('Selecione um produto válido da sua loja.'); }
        if ($product['sale_type'] === 'own' && $status === 'paid') {
            if ((int) $product['stock_qty'] < $quantity) { throw new DomainException('Estoque insuficiente. Atualize o estoque antes de confirmar a venda.'); }
            $s = $pdo->prepare('UPDATE products SET stock_qty = stock_qty - ? WHERE id = ? AND tenant_id = ? AND stock_qty >= ?');
            $s->execute(array($quantity, $productId, $tenantId, $quantity));
            if ($s->rowCount() !== 1) { throw new DomainException('Estoque alterado. Confira a quantidade e tente novamente.'); }
        }
        $s = $pdo->prepare('INSERT INTO orders (tenant_id, order_type, status, customer_name, notes, revenue, cost_total, profit) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $s->execute(array($tenantId, $product['sale_type'], $status, $customerName ?: null, $notes ?: null, $revenue, $costTotal, round($revenue - $costTotal, 2)));
        $orderId = (int) $pdo->lastInsertId();
        $s = $pdo->prepare('INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)');
        $s->execute(array($orderId, $productId, $quantity, round($revenue / $quantity, 2)));
        $pdo->commit();
        return $orderId;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        throw $e;
    }
}

function change_order_status($tenantId, $orderId, $status)
{
    if (!in_array($status, array('paid', 'cancelled'), true)) { throw new DomainException('Escolha um status válido.'); }
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare('SELECT * FROM orders WHERE id = ? AND tenant_id = ? FOR UPDATE');
        $s->execute(array($orderId, $tenantId));
        $order = $s->fetch();
        if (!$order) { throw new DomainException('Pedido não encontrado na sua loja.'); }
        if ($order['status'] === $status) { $pdo->commit(); return; }
        if ($order['status'] === 'cancelled') { throw new DomainException('Pedidos cancelados não podem ser reabertos. Faça um novo lançamento.'); }
        $s = $pdo->prepare('SELECT product_id, quantity FROM order_items WHERE order_id = ? ORDER BY product_id');
        $s->execute(array($orderId));
        $items = $s->fetchAll();
        if ($order['order_type'] === 'own') {
            foreach ($items as $item) {
                $s = $pdo->prepare('SELECT stock_qty FROM products WHERE id = ? AND tenant_id = ? FOR UPDATE');
                $s->execute(array($item['product_id'], $tenantId));
                $product = $s->fetch();
                if (!$product) { throw new DomainException('O produto deste pedido não está disponível.'); }
                $delta = $status === 'paid' ? -(int) $item['quantity'] : ($order['status'] === 'paid' ? (int) $item['quantity'] : 0);
                if ((int) $product['stock_qty'] + $delta < 0) { throw new DomainException('Estoque insuficiente para confirmar este pedido.'); }
                $s = $pdo->prepare('UPDATE products SET stock_qty = stock_qty + ? WHERE id = ? AND tenant_id = ?');
                $s->execute(array($delta, $item['product_id'], $tenantId));
            }
        }
        $s = $pdo->prepare('UPDATE orders SET status = ? WHERE id = ? AND tenant_id = ?');
        $s->execute(array($status, $orderId, $tenantId));
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        throw $e;
    }
}
