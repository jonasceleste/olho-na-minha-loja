<?php

function app_config($section = null, $key = null)
{
    global $config;

    if ($section === null) {
        return $config;
    }

    if ($key === null) {
        return isset($config[$section]) ? $config[$section] : null;
    }

    return isset($config[$section][$key]) ? $config[$section][$key] : null;
}

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function app_url($path = '')
{
    $base = rtrim((string) app_config('app', 'base_url'), '/') . '/';
    return $base . ltrim($path, '/');
}

function redirect_to($path)
{
    if (preg_match('/^https?:\/\//i', $path)) {
        header('Location: ' . $path);
    } else {
        header('Location: ' . app_url($path));
    }
    exit;
}

function flash($key, $message = null)
{
    if ($message !== null) {
        if (!isset($_SESSION['_flash'])) {
            $_SESSION['_flash'] = array();
        }
        $_SESSION['_flash'][$key] = $message;
        return null;
    }

    if (isset($_SESSION['_flash'][$key])) {
        $value = $_SESSION['_flash'][$key];
        unset($_SESSION['_flash'][$key]);
        return $value;
    }

    return null;
}

function csrf_token()
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function verify_csrf($token)
{
    return is_string($token)
        && !empty($_SESSION['_csrf'])
        && hash_equals($_SESSION['_csrf'], $token);
}

function post_value($key, $default = '')
{
    return isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : $default;
}

function input_value($data, $key, $default = '')
{
    return isset($data[$key]) && is_string($data[$key]) ? trim($data[$key]) : $default;
}

function text_length($value)
{
    return preg_match_all('/./us', $value, $matches) ?: 0;
}

function valid_text($value, $min, $max)
{
    return preg_match('//u', $value) && strpos($value, "\0") === false
        && text_length($value) >= $min && text_length($value) <= $max;
}

function valid_password($value)
{
    return is_string($value) && valid_text($value, 8, 72) && strlen($value) <= 72
        && trim($value) === $value;
}

function valid_whatsapp($value)
{
    return $value === '' || preg_match('/\A[1-9][0-9]{9,14}\z/', $value);
}

function to_float($value)
{
    $value = trim((string) $value);
    if ($value === '') { return 0.0; }
    // Accept 1234.56, 1234,56 and 1.234,56. Reject ambiguous/garbled input.
    if (preg_match('/\A(?:[0-9]{1,3}(?:\.[0-9]{3})+|[0-9]+),[0-9]{1,2}\z/', $value)) {
        $value = str_replace(',', '.', str_replace('.', '', $value));
    } elseif (!preg_match('/\A[0-9]+(?:\.[0-9]{1,2})?\z/', $value)) {
        return null;
    }
    $number = (float) $value;
    return is_finite($number) && $number <= 9999999999.99 ? round($number, 2) : null;
}

function positive_integer($value, $min = 1, $max = 1000000)
{
    if (!preg_match('/\A[0-9]+\z/', (string) $value)) { return null; }
    $value = (int) $value;
    return $value >= $min && $value <= $max ? $value : null;
}

function money($value)
{
    return 'R$ ' . number_format((float) $value, 2, ',', '.');
}

function slugify($value)
{
    $value = trim((string) $value);
    $value = strtr($value, array('á'=>'a','à'=>'a','ã'=>'a','â'=>'a','ä'=>'a','Á'=>'A','À'=>'A','Ã'=>'A','Â'=>'A','Ä'=>'A','é'=>'e','è'=>'e','ê'=>'e','ë'=>'e','É'=>'E','È'=>'E','Ê'=>'E','Ë'=>'E','í'=>'i','ì'=>'i','î'=>'i','ï'=>'i','Í'=>'I','Ì'=>'I','Î'=>'I','Ï'=>'I','ó'=>'o','ò'=>'o','õ'=>'o','ô'=>'o','ö'=>'o','Ó'=>'O','Ò'=>'O','Õ'=>'O','Ô'=>'O','Ö'=>'O','ú'=>'u','ù'=>'u','û'=>'u','ü'=>'u','Ú'=>'U','Ù'=>'U','Û'=>'U','Ü'=>'U','ç'=>'c','Ç'=>'C'));
    if (function_exists('iconv')) {
        $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if ($converted !== false) {
            $value = $converted;
        }
    }

    $value = strtolower($value);
    $value = preg_replace('/[^a-z0-9]+/', '-', $value);
    $value = trim($value, '-');
    return $value !== '' ? $value : 'minha-loja';
}

function unique_slug($desired)
{
    $base = substr(slugify($desired), 0, 100);
    $slug = $base;
    $number = 2;

    $stmt = db()->prepare('SELECT id FROM tenants WHERE slug = ? LIMIT 1');
    while (true) {
        $stmt->execute(array($slug));
        if (!$stmt->fetch()) {
            return $slug;
        }
        $slug = $base . '-' . $number;
        $number++;
    }
}

function valid_http_url($url)
{
    if (!is_string($url) || preg_match('/[\x00-\x20\x7f]/', $url) || !filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }
    $parts = parse_url($url);
    return !isset($parts['user']) && !isset($parts['pass']) && isset($parts['scheme']) && in_array(strtolower($parts['scheme']), array('http', 'https'), true);
}

function store_url($slug)
{
    return app_url('loja.php?slug=' . rawurlencode($slug));
}

function whatsapp_url($number, $message)
{
    $digits = preg_replace('/\D+/', '', (string) $number);
    if ($digits === '') {
        return '';
    }
    return 'https://wa.me/' . $digits . '?text=' . rawurlencode($message);
}

function current_user()
{
    static $user = false;

    if ($user !== false) {
        return $user;
    }

    if (empty($_SESSION['user_id'])) {
        $user = null;
        return $user;
    }

    $stmt = db()->prepare('SELECT u.*, t.name AS tenant_name, t.slug AS tenant_slug, t.whatsapp AS tenant_whatsapp FROM users u INNER JOIN tenants t ON t.id = u.tenant_id WHERE u.id = ? AND u.status = "active" AND t.status = "active" LIMIT 1');
    $stmt->execute(array((int) $_SESSION['user_id']));
    $user = $stmt->fetch() ?: null;
    if ($user && (empty($_SESSION['auth_password_stamp']) || !hash_equals(hash('sha256', $user['password_hash']), $_SESSION['auth_password_stamp']))) {
        unset($_SESSION['user_id'], $_SESSION['auth_password_stamp']);
        $user = null;
    }
    return $user;
}

function current_tenant()
{
    $user = current_user();
    if (!$user) {
        return null;
    }

    $stmt = db()->prepare('SELECT * FROM tenants WHERE id = ? LIMIT 1');
    $stmt->execute(array((int) $user['tenant_id']));
    return $stmt->fetch() ?: null;
}

function require_login()
{
    if (!current_user()) {
        flash('error', 'Faça login para acessar o painel.');
        redirect_to('index.php');
    }
}

function tenant_id()
{
    $user = current_user();
    return $user ? (int) $user['tenant_id'] : 0;
}

function record_page_view($tenantId, $productId = null)
{
    $stmt = db()->prepare('INSERT INTO page_views (tenant_id, product_id, path) VALUES (?, ?, ?)');
    $stmt->execute(array(
        (int) $tenantId,
        $productId ? (int) $productId : null,
        isset($_SERVER['REQUEST_URI']) ? substr((string) $_SERVER['REQUEST_URI'], 0, 255) : 'loja.php',
    ));
}

function record_click($tenantId, $productId, $source = 'store')
{
    $stmt = db()->prepare('INSERT INTO click_events (tenant_id, product_id, source) VALUES (?, ?, ?)');
    $stmt->execute(array((int) $tenantId, (int) $productId, substr((string) $source, 0, 40)));
}

function order_status_label($status)
{
    $labels = array(
        'paid' => 'Confirmado',
        'pending' => 'Pendente',
        'cancelled' => 'Cancelado',
    );
    return isset($labels[$status]) ? $labels[$status] : ucfirst($status);
}

function sale_type_label($type)
{
    return $type === 'affiliate' ? 'Afiliado' : 'Estoque próprio';
}

function old_or($value, $fallback)
{
    return $value !== '' ? $value : $fallback;
}
