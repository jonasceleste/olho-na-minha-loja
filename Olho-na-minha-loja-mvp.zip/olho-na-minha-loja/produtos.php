<?php
require __DIR__ . '/includes/bootstrap.php';
require_login();

$page_title = 'Produtos e ofertas';
$tenantId = tenant_id();
$editProduct = null;
if (!empty($_GET['edit'])) {
    $stmt = db()->prepare('SELECT * FROM products WHERE id = ? AND tenant_id = ? LIMIT 1');
    $stmt->execute(array((int) input_value($_GET, 'edit'), $tenantId));
    $editProduct = $stmt->fetch() ?: null;
}

$stmt = db()->prepare('SELECT p.*, (SELECT COUNT(*) FROM click_events c WHERE c.product_id = p.id AND c.tenant_id = p.tenant_id) AS clicks FROM products p WHERE p.tenant_id = ? ORDER BY p.created_at DESC');
$stmt->execute(array($tenantId));
$products = $stmt->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<section class="grid editor-grid">
    <article class="panel">
        <div class="panel-header"><div><h2><?php echo $editProduct ? 'Editar produto' : 'Adicionar oferta'; ?></h2><p>Cadastre um produto próprio ou uma indicação afiliada.</p></div><span class="badge badge-blue">Produtos</span></div>
        <form method="post" action="<?php echo e(app_url('produto_salvar.php')); ?>">
            <input type="hidden" name="_csrf" value="<?php echo e(csrf_token()); ?>">
            <?php if ($editProduct): ?><input type="hidden" name="id" value="<?php echo (int) $editProduct['id']; ?>"><?php endif; ?>
            <div class="form-grid">
                <div class="field full"><label for="sale_type">Como a venda acontece?</label><select id="sale_type" name="sale_type" onchange="toggleAffiliateFields()"><option value="own" <?php echo (!$editProduct || $editProduct['sale_type'] === 'own') ? 'selected' : ''; ?>>Produto próprio — tenho estoque</option><option value="affiliate" <?php echo ($editProduct && $editProduct['sale_type'] === 'affiliate') ? 'selected' : ''; ?>>Produto afiliado — indicar oferta externa</option></select></div>
                <div class="field full"><label for="name">Nome do produto</label><input id="name" name="name" maxlength="180" type="text" value="<?php echo e($editProduct ? $editProduct['name'] : ''); ?>" placeholder="Ex.: Fone Bluetooth Pro" required></div>
                <div class="field"><label for="price">Preço exibido</label><input id="price" name="price" type="text" inputmode="decimal" value="<?php echo e($editProduct ? number_format($editProduct['price'], 2, ',', '.') : ''); ?>" placeholder="0,00" required><small>Para afiliado, é o preço que você quer mostrar na vitrine.</small></div>
                <div class="field"><label for="cost_price">Custo por unidade</label><input id="cost_price" name="cost_price" type="text" inputmode="decimal" value="<?php echo e($editProduct ? number_format($editProduct['cost_price'], 2, ',', '.') : ''); ?>" placeholder="0,00"><small>Produto próprio: custo. Afiliado: use 0 e lance a comissão em Vendas.</small></div>
                <div class="field"><label for="category">Categoria</label><input id="category" name="category" maxlength="80" type="text" value="<?php echo e($editProduct ? $editProduct['category'] : ''); ?>" placeholder="Ex.: Eletrônicos"></div>
                <div class="field"><label for="stock_qty">Estoque disponível</label><input id="stock_qty" name="stock_qty" type="number" min="0" step="1" value="<?php echo e($editProduct ? (int) $editProduct['stock_qty'] : '0'); ?>"><small>Usado para produtos próprios. Zero significa produto esgotado.</small></div>
                <div class="field full"><label for="image_url">URL da imagem</label><input id="image_url" name="image_url" maxlength="500" type="url" value="<?php echo e($editProduct ? $editProduct['image_url'] : ''); ?>" placeholder="https://..."><small>Use uma imagem pública HTTPS. O upload direto pode ser adicionado em uma próxima etapa.</small></div>
                <div class="field full" id="affiliate-field"><label for="affiliate_url">Link da oferta / afiliado</label><input id="affiliate_url" name="affiliate_url" maxlength="1000" type="url" value="<?php echo e($editProduct ? $editProduct['affiliate_url'] : ''); ?>" placeholder="https://shopee.com.br/... ou https://mercadolivre.com.br/..."><small>O sistema registra o clique antes de enviar o visitante para este endereço.</small></div>
                <div class="field full"><label for="description">Descrição curta</label><textarea id="description" name="description" maxlength="5000" placeholder="Explique o principal benefício do produto."><?php echo e($editProduct ? $editProduct['description'] : ''); ?></textarea></div>
                <div class="field"><label for="status">Situação</label><select id="status" name="status"><option value="published" <?php echo (!$editProduct || $editProduct['status'] === 'published') ? 'selected' : ''; ?>>Publicado na loja</option><option value="draft" <?php echo ($editProduct && $editProduct['status'] === 'draft') ? 'selected' : ''; ?>>Salvar como rascunho</option></select></div>
            </div>
            <div class="form-actions"><a class="button button-secondary" href="<?php echo e(app_url('produtos.php')); ?>">Limpar</a><button class="button button-primary" type="submit"><?php echo $editProduct ? 'Salvar alterações' : 'Adicionar produto'; ?></button></div>
        </form>
    </article>
    <article class="panel">
        <div class="panel-header"><div><h2>Como funciona</h2><p>O fluxo que o cliente verá.</p></div></div>
        <div class="suggestions">
            <div class="suggestion"><span class="suggestion-icon">1</span><div><strong>Produto próprio</strong><p>O botão abre o WhatsApp da loja com uma mensagem pronta. Você registra o pedido no painel.</p></div></div>
            <div class="suggestion"><span class="suggestion-icon">2</span><div><strong>Produto afiliado</strong><p>O botão passa pelo rastreador e leva ao link da Shopee, Mercado Livre ou outra plataforma.</p></div></div>
            <div class="suggestion"><span class="suggestion-icon">3</span><div><strong>Dados separados</strong><p>Cliques, pedidos e lucros ficam ligados à sua conta e não aparecem para outros clientes.</p></div></div>
        </div>
    </article>
</section>

<section class="panel" style="margin-top:18px;">
    <div class="panel-header"><div><h2>Produtos cadastrados</h2><p><?php echo number_format(count($products), 0, ',', '.'); ?> produto(s) na sua loja.</p></div></div>
    <?php if (!$products): ?>
        <div class="empty-state"><h3>Nenhum produto ainda.</h3><p>Preencha o formulário acima para publicar a primeira oferta.</p></div>
    <?php else: ?>
        <div class="table-wrap"><table><thead><tr><th>Produto</th><th>Tipo</th><th>Preço</th><th>Estoque</th><th>Cliques</th><th>Ações</th></tr></thead><tbody>
        <?php foreach ($products as $product): ?>
            <tr><td><div class="product-cell"><?php if (!empty($product['image_url'])): ?><img class="product-thumb" src="<?php echo e($product['image_url']); ?>" alt=""><?php else: ?><span class="product-thumb"></span><?php endif; ?><div><strong><?php echo e($product['name']); ?></strong><small><?php echo e(($product['status'] === 'archived' ? 'Arquivado · ' : ($product['status'] === 'draft' ? 'Rascunho · ' : 'Publicado · ')) . ($product['category'] ?: 'Sem categoria')); ?></small></div></div></td><td><span class="badge <?php echo $product['sale_type'] === 'affiliate' ? 'badge-blue' : 'badge-green'; ?>"><?php echo e(sale_type_label($product['sale_type'])); ?></span></td><td><?php echo e(money($product['price'])); ?></td><td><?php echo $product['sale_type'] === 'affiliate' ? '—' : number_format((int) $product['stock_qty'], 0, ',', '.'); ?></td><td><?php echo number_format((int) $product['clicks'], 0, ',', '.'); ?></td><td><a class="button button-secondary button-small" href="<?php echo e(app_url('produtos.php?edit=' . (int) $product['id'])); ?>">Editar</a> <form style="display:inline" method="post" action="<?php echo e(app_url('produto_excluir.php')); ?>"><input type="hidden" name="_csrf" value="<?php echo e(csrf_token()); ?>"><input type="hidden" name="id" value="<?php echo (int) $product['id']; ?>"><button class="button button-danger button-small" type="submit" data-confirm="Arquivar este produto? Ele deixará de aparecer na loja.">Arquivar</button></form></td></tr>
        <?php endforeach; ?>
        </tbody></table></div>
    <?php endif; ?>
</section>
<script>
function toggleAffiliateFields() {
    var type = document.getElementById('sale_type').value;
    var field = document.getElementById('affiliate-field');
    field.style.display = type === 'affiliate' ? '' : 'none';
    document.getElementById('affiliate_url').required = type === 'affiliate';
}
toggleAffiliateFields();
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
