<?php
require __DIR__ . '/includes/bootstrap.php';
require_login();

$page_title = 'Vendas e pedidos';
$tenantId = tenant_id();
if (empty($_SESSION['order_nonce'])) { $_SESSION['order_nonce'] = bin2hex(random_bytes(32)); }

$productsStmt = db()->prepare('SELECT id, name, sale_type, price, cost_price, stock_qty FROM products WHERE tenant_id = ? AND status <> "archived" ORDER BY name ASC');
$productsStmt->execute(array($tenantId));
$productOptions = $productsStmt->fetchAll();

$ordersStmt = db()->prepare('SELECT o.*, oi.quantity, oi.unit_price, p.name AS product_name, p.sale_type FROM orders o LEFT JOIN order_items oi ON oi.order_id = o.id LEFT JOIN products p ON p.id = oi.product_id WHERE o.tenant_id = ? ORDER BY o.created_at DESC LIMIT 50');
$ordersStmt->execute(array($tenantId));
$orders = $ordersStmt->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<section class="grid editor-grid">
    <article class="panel">
        <div class="panel-header"><div><h2>Registrar venda</h2><p>Use para alimentar os gráficos com vendas confirmadas ou pendentes.</p></div><span class="badge badge-green">manual</span></div>
        <?php if (!$productOptions): ?>
            <div class="empty-state"><h3>Cadastre um produto primeiro.</h3><p>O pedido precisa estar ligado a um produto da sua loja.</p><a class="button button-primary" href="<?php echo e(app_url('produtos.php')); ?>">Ir para produtos</a></div>
        <?php else: ?>
        <form method="post" action="<?php echo e(app_url('pedido_salvar.php')); ?>">
            <input type="hidden" name="_csrf" value="<?php echo e(csrf_token()); ?>">
            <input type="hidden" name="order_nonce" value="<?php echo e($_SESSION['order_nonce']); ?>">
            <div class="form-grid">
                <div class="field full"><label for="product_id">Produto vendido</label><select id="product_id" name="product_id" onchange="fillOrderDefaults()" required><option value="">Selecione um produto</option><?php foreach ($productOptions as $product): ?><option value="<?php echo (int) $product['id']; ?>" data-price="<?php echo e($product['price']); ?>" data-cost="<?php echo e($product['cost_price']); ?>" data-type="<?php echo e($product['sale_type']); ?>"><?php echo e($product['name']); ?> · <?php echo e(sale_type_label($product['sale_type'])); ?></option><?php endforeach; ?></select></div>
                <div class="field"><label for="quantity">Quantidade</label><input id="quantity" name="quantity" type="number" min="1" step="1" value="1" onchange="fillOrderDefaults()" required></div>
                <div class="field"><label for="revenue" id="revenue-label">Valor recebido / comissão</label><input id="revenue" name="revenue" type="text" inputmode="decimal" placeholder="0,00" required><small>Para afiliado, informe a comissão que você recebeu. Para estoque, informe o total vendido.</small></div>
                <div class="field"><label for="cost_total">Custos totais</label><input id="cost_total" name="cost_total" type="text" inputmode="decimal" placeholder="0,00"><small>Produto, frete, taxa de pagamento ou outros custos.</small></div>
                <div class="field"><label for="status">Situação</label><select id="status" name="status"><option value="paid">Confirmado</option><option value="pending">Pendente</option><option value="cancelled">Cancelado</option></select></div>
                <div class="field"><label for="customer_name">Cliente <span style="font-weight:400;color:#8993a8">(opcional)</span></label><input id="customer_name" name="customer_name" maxlength="120" type="text" placeholder="Nome ou identificação"></div>
                <div class="field full"><label for="notes">Observação <span style="font-weight:400;color:#8993a8">(opcional)</span></label><input id="notes" name="notes" type="text" maxlength="500" placeholder="Ex.: pedido feito pelo WhatsApp"></div>
            </div>
            <div class="form-actions"><button class="button button-primary" type="submit">Salvar pedido</button></div>
        </form>
        <?php endif; ?>
    </article>
    <article class="panel">
        <div class="panel-header"><div><h2>Como os números entram</h2><p>Transparência sobre os dados do gráfico.</p></div></div>
        <div class="suggestions">
            <div class="suggestion"><span class="suggestion-icon">R$</span><div><strong>Receita</strong><p>Produto próprio: total vendido. Produto afiliado: comissão recebida, lançada por você.</p></div></div>
            <div class="suggestion"><span class="suggestion-icon">−</span><div><strong>Lucro</strong><p>O sistema calcula automaticamente: valor recebido menos custos totais.</p></div></div>
            <div class="suggestion"><span class="suggestion-icon">✓</span><div><strong>Confirmado</strong><p>Apenas pedidos confirmados entram nos indicadores. Confirme ou cancele os pendentes no histórico. O gráfico usa a data original do lançamento.</p></div></div>
        </div>
    </article>
</section>

<section class="panel" style="margin-top:18px;">
    <div class="panel-header"><div><h2>Histórico de pedidos</h2><p>Últimos 50 lançamentos da sua loja.</p></div></div>
    <?php if (!$orders): ?>
        <div class="empty-state"><h3>O histórico está vazio.</h3><p>Depois que registrar sua primeira venda, ela aparecerá aqui e no painel.</p></div>
    <?php else: ?>
        <div class="table-wrap"><table><thead><tr><th>Data</th><th>Produto</th><th>Tipo</th><th>Situação</th><th>Receita</th><th>Lucro</th><th>Ações</th></tr></thead><tbody>
        <?php foreach ($orders as $order): ?>
            <tr><td><?php echo e(date('d/m/Y H:i', strtotime($order['created_at']))); ?></td><td><strong><?php echo e($order['product_name'] ?: 'Produto removido'); ?></strong><small style="display:block;color:#8993a8;margin-top:3px;"><?php echo number_format((int) $order['quantity'], 0, ',', '.'); ?> unidade(s)</small></td><td><span class="badge <?php echo $order['order_type'] === 'affiliate' ? 'badge-blue' : 'badge-green'; ?>"><?php echo e(sale_type_label($order['order_type'] ?: 'own')); ?></span></td><td><span class="badge <?php echo $order['status'] === 'paid' ? 'badge-green' : ($order['status'] === 'pending' ? 'badge-orange' : 'badge-gray'); ?>"><?php echo e(order_status_label($order['status'])); ?></span></td><td><?php echo e(money($order['revenue'])); ?></td><td><?php echo e(money($order['profit'])); ?></td><td>
<?php if ($order['status'] !== 'cancelled'): ?>
<form method="post" action="<?php echo e(app_url('pedido_status.php')); ?>">
<input type="hidden" name="_csrf" value="<?php echo e(csrf_token()); ?>"><input type="hidden" name="id" value="<?php echo (int) $order['id']; ?>">
<?php if ($order['status'] === 'pending'): ?><button class="button button-small button-primary" name="status" value="paid">Confirmar</button><?php endif; ?>
<button class="button button-small button-danger" name="status" value="cancelled" data-confirm="Cancelar este pedido? Se confirmado, o estoque será devolvido.">Cancelar</button></form>
<?php else: ?>—<?php endif; ?></td></tr>
        <?php endforeach; ?>
        </tbody></table></div>
    <?php endif; ?>
</section>
<script>
function fillOrderDefaults() {
    var select = document.getElementById('product_id');
    var option = select.options[select.selectedIndex];
    if (!option || !option.value) return;
    var quantity = parseInt(document.getElementById('quantity').value || '1', 10);
    var price = Number(option.getAttribute('data-price') || 0);
    var type = option.getAttribute('data-type');
    document.getElementById('revenue').value = type === 'affiliate' ? '' : (price * quantity).toFixed(2).replace('.', ',');
    document.getElementById('cost_total').value = type === 'affiliate' ? '0,00' : (Number(option.getAttribute('data-cost') || 0) * quantity).toFixed(2).replace('.', ',');
    document.getElementById('revenue-label').textContent = type === 'affiliate' ? 'Comissão recebida' : 'Valor recebido';
}
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
