<?php
require __DIR__ . '/includes/bootstrap.php';
require_login();

$page_title = 'Configurações';
$tenant = current_tenant();
$user = current_user();
require __DIR__ . '/includes/header.php';
?>
<section class="grid editor-grid">
    <article class="panel">
        <div class="panel-header"><div><h2>Identidade da loja</h2><p>Essas informações aparecem na vitrine pública e no WhatsApp.</p></div><span class="badge badge-blue">Sua conta</span></div>
        <form method="post" action="<?php echo e(app_url('configuracao_salvar.php')); ?>">
            <input type="hidden" name="_csrf" value="<?php echo e(csrf_token()); ?>">
            <div class="form-grid">
                <div class="field full"><label for="store_name">Nome da loja</label><input id="store_name" name="store_name" maxlength="120" type="text" value="<?php echo e($tenant['name']); ?>" required></div>
                <div class="field"><label for="owner_name">Nome do responsável</label><input id="owner_name" name="owner_name" maxlength="120" type="text" value="<?php echo e($tenant['owner_name']); ?>" required></div>
                <div class="field"><label for="whatsapp">WhatsApp da loja</label><input id="whatsapp" name="whatsapp" maxlength="25" type="text" value="<?php echo e($tenant['whatsapp']); ?>" placeholder="5511999999999"><small>Inclua país e DDD, sem espaços ou símbolos.</small></div>
                <div class="field"><label for="brand_color">Cor da marca</label><input id="brand_color" name="brand_color" type="color" value="<?php echo e($tenant['brand_color']); ?>" style="height:44px;padding:4px 7px;"></div>
                <div class="field"><label>Link exclusivo</label><input type="text" value="<?php echo e(store_url($tenant['slug'])); ?>" readonly><small>Este endereço identifica sua loja e registra seus cliques.</small></div>
            </div>
            <div class="form-actions"><button class="button button-primary" type="submit">Salvar configurações</button></div>
        </form>
    </article>
    <article class="panel">
        <div class="panel-header"><div><h2>Conta de acesso</h2><p>Dados usados para entrar no painel.</p></div></div>
        <div class="suggestions">
            <div class="suggestion"><span class="suggestion-icon">@</span><div><strong><?php echo e($user['name']); ?></strong><p><?php echo e($user['email']); ?></p></div></div>
            <div class="suggestion"><span class="suggestion-icon">✓</span><div><strong>Dados separados</strong><p>Seu painel usa o identificador da sua loja para filtrar produtos, cliques, pedidos e lucros.</p></div></div>
            <div class="suggestion"><span class="suggestion-icon">🔒</span><div><strong>Proteção básica ativa</strong><p>O sistema usa senha protegida, sessão segura, formulários com token e consultas preparadas.</p></div></div>
        </div>
    </article>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
