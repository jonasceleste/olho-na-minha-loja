<?php
require __DIR__ . '/includes/bootstrap.php';

$slug = input_value($_GET, 'slug');
$tenantStmt = db()->prepare('SELECT * FROM tenants WHERE slug = ? AND status = "active" LIMIT 1');
$tenantStmt->execute(array($slug));
$tenant = $tenantStmt->fetch();

if (!$tenant) {
    http_response_code(404);
    $page_title = 'Loja não encontrada';
    require __DIR__ . '/includes/header.php';
    echo '<div class="empty-state" style="max-width:560px;margin:15vh auto;"><h3>Esta loja não foi encontrada.</h3><p>O link pode estar incorreto ou a loja ainda não foi ativada.</p></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

record_page_view($tenant['id']);
$productsStmt = db()->prepare('SELECT * FROM products WHERE tenant_id = ? AND status = "published" ORDER BY created_at DESC');
$productsStmt->execute(array((int) $tenant['id']));
$products = $productsStmt->fetchAll();
$page_title = $tenant['name'];
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="<?php echo e($tenant['brand_color']); ?>">
    <title><?php echo e($tenant['name']); ?> · Olho na Minha Loja</title>
    <link rel="stylesheet" href="<?php echo e(app_url('assets/app.css')); ?>">
</head>
<body>
<div class="public-page">
    <header class="public-header">
        <a class="brand" href="<?php echo e(store_url($tenant['slug'])); ?>"><span class="brand-mark" style="background:<?php echo e($tenant['brand_color']); ?>">O</span><span><strong><?php echo e($tenant['name']); ?></strong><small>Ofertas e produtos</small></span></a>
        <?php if (!empty($tenant['whatsapp'])): ?><a class="button button-secondary button-small" href="<?php echo e(whatsapp_url($tenant['whatsapp'], 'Olá! Vim pela loja ' . $tenant['name'] . '.')); ?>" target="_blank" rel="noopener">Falar no WhatsApp</a><?php endif; ?>
    </header>
    <section class="public-hero"><div><span class="eyebrow">VITRINE ONLINE</span><h1>Escolha o que faz sentido para você.</h1><p>Confira os produtos e ofertas selecionados por <?php echo e($tenant['owner_name']); ?>.</p></div><span class="badge badge-blue"><?php echo number_format(count($products), 0, ',', '.'); ?> oferta(s)</span></section>
    <?php if (!$products): ?>
        <div class="public-card" style="max-width:600px;margin:30px auto;padding:35px;text-align:center;"><h2>Em breve</h2><p>Esta loja está preparando os primeiros produtos.</p></div>
    <?php else: ?>
        <section class="public-grid">
        <?php foreach ($products as $product): ?>
            <article class="public-card" id="produto-<?php echo (int) $product['id']; ?>">
                <?php if (!empty($product['image_url'])): ?><img src="<?php echo e($product['image_url']); ?>" alt="<?php echo e($product['name']); ?>" loading="lazy"><?php else: ?><div style="height:185px;background:linear-gradient(135deg,#e8edff,#f6eefe);display:grid;place-items:center;color:#7890d4;font-size:42px;font-weight:800;">O</div><?php endif; ?>
                <div class="public-card-body"><span class="badge <?php echo $product['sale_type'] === 'affiliate' ? 'badge-blue' : 'badge-green'; ?>"><?php echo e(sale_type_label($product['sale_type'])); ?></span><h2><?php echo e($product['name']); ?></h2><p><?php echo e($product['description'] ?: 'Confira os detalhes desta oferta.'); ?></p><div class="public-price"><?php echo e(money($product['price'])); ?></div><?php if ($product['sale_type'] === 'own' && ((int) $product['stock_qty'] <= 0 || empty($tenant['whatsapp']) || !valid_whatsapp($tenant['whatsapp']))): ?><span class="button button-secondary button-block"><?php echo (int) $product['stock_qty'] <= 0 ? 'Esgotado' : 'Contato indisponível'; ?></span><?php else: ?><a class="button button-primary button-block" href="<?php echo e(app_url('redirect.php?product=' . (int) $product['id'] . '&source=store')); ?>" target="_blank" rel="noopener"><?php echo $product['sale_type'] === 'affiliate' ? 'Ver oferta ↗' : 'Pedir pelo WhatsApp ↗'; ?></a><?php endif; ?></div>
            </article>
        <?php endforeach; ?>
        </section>
    <?php endif; ?>
    <footer class="public-footer">Link e indicadores gerenciados com Olho na Minha Loja.</footer>
</div>
</body>
</html>
