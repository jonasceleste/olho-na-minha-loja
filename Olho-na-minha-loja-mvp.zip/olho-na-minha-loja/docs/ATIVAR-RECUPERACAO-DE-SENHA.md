# Atualização: recuperação de senha por e-mail

O cadastro de clientes continua em register.php. O login agora tem “Esqueci minha senha”. O cliente informa o e-mail, recebe um link e define a nova senha. O link vale 30 minutos, funciona uma única vez e um novo pedido invalida o anterior. A senha antiga continua válida até concluir a troca. As sessões anteriores são encerradas na próxima navegação após a troca.

## Se o sistema já estiver instalado

1. Faça backup dos arquivos e do banco atual.
2. Para esta revisão completa, substitua todos os arquivos da aplicação conforme COMECE-AQUI.md, preservando config.php e config.mail.php. Não atualize apenas os arquivos de recuperação.
3. Não substitua config.php: ele contém a configuração atual do seu banco e endereço. Não importe database.sql na atualização.
4. No phpMyAdmin, selecione o banco do Olho na Minha Loja e importe sql/atualizacao-recuperacao-senha.sql. Essa migração só cria duas tabelas novas e pode ser reaplicada; não apaga clientes, lojas ou produtos.
5. Copie config.mail.example.php para config.mail.php na mesma pasta de config.php. Informe em `from` um e-mail real do seu domínio, criado na hospedagem. Troque `enabled` de false para true.
6. Confira se app/base_url em config.php contém o endereço HTTPS completo da instalação, terminando em /olho/ se essa for a pasta. O envio exige HTTPS na URL configurada.
7. Faça o teste de recebimento abaixo. Os usuários precisarão entrar novamente após esta atualização, pois a validação das sessões foi reforçada.

## Como o envio funciona

Usa PHP mail() e o serviço de e-mail local da hospedagem. Não requer a senha da caixa de e-mail no código. Não é uma integração com SMTP externo ou Gmail. O envio precisa estar habilitado no plano/servidor; o remetente deve ser autorizado pelo provedor. A aceitação pela função mail() não garante chegada à caixa de entrada (referência: https://www.php.net/manual/en/function.mail.php).

No cPanel, confira a conta de e-mail do remetente e a configuração de entregabilidade do domínio (SPF/DKIM) com o suporte da hospedagem. Se não chegar, consulte spam, rastreamento de entrega e log de erros do PHP. Logs do aplicativo indicam falha de configuração/transporte sem registrar tokens ou senhas. Caso a hospedagem exija SMTP autenticado, será necessária uma adaptação do transporte.

## Primeira instalação

Siga GUIA-HOSTGATOR.md. O database.sql completo já contém as novas tabelas. Configure config.mail.php como explicado acima. Não publique arquivos de testes, backups ou este ZIP dentro de public_html.

## Teste de aceitação na hospedagem

- Crie ou use uma conta sua e abra “Esqueci minha senha”. Solicite o link e verifique recebimento (inclusive spam).
- Abra o link, informe senhas diferentes: o formulário deve recusar.
- Informe uma senha de pelo menos 8 caracteres, confirme e salve. O sistema volta ao login. A senha antiga deve falhar e a nova deve funcionar.
- Reabra o link usado: ele deve ser recusado. Um link com token alterado também deve ser recusado.
- Solicite dois links: apenas o mais recente deve funcionar. Depois de 30 minutos, o link deve expirar.
- Mantenha uma sessão em outro navegador; após a troca, ao navegar ela deve voltar ao login.
- Solicite para um endereço não cadastrado: a mensagem deve ser igual à de um endereço cadastrado, sem revelar a existência da conta.
- Limites: até 3 pedidos por e-mail e 10 por IP em uma janela de uma hora. Excedentes recebem a mesma mensagem, sem novo envio.

## Validação desta entrega

O código foi revisado, todos os arquivos PHP passaram pela análise sintática do PHP 8.3 e o pacote foi conferido. Os fluxos foram executados em PHP 8.3 com banco SQLite adaptado exclusivamente para testes. Ainda é necessário validar MySQL/MariaDB, concorrência, Apache e entrega real de e-mail na hospedagem. Veja REVISAO-E-TESTES.md. Nenhum e-mail real foi enviado durante a preparação.
