# Revisão do código — 23/10/2026

## Escopo

Revisão dos arquivos PHP, JavaScript, CSS, SQL, regras do Apache e guias. Esta entrega é um pacote para instalar/atualizar; não houve acesso nem alteração ao servidor HostGator do proprietário.

## Erros corrigidos

1. **Página de configurações bloqueada:** a regra antiga do `.htaccess` bloqueava qualquer nome começando com `config`, incluindo `configuracoes.php` e `configuracao_salvar.php`. A regra agora identifica apenas os arquivos de configuração; as pastas internas também têm proteção própria.
2. **HTML no gráfico:** nomes de produtos eram inseridos com `innerHTML`. Agora são nós de texto, evitando interpretação de HTML ou scripts inseridos no nome.
3. **Comissões incorretas:** selecionar um produto afiliado preenchia a receita com o preço de vitrine. Agora a comissão fica vazia para o lojista informar o valor efetivamente recebido.
4. **Estoque zero e concorrência:** vendas confirmadas de produtos próprios exigem estoque, usam transação e leitura bloqueada do produto; uma falha impede gravação parcial. O botão da vitrine informa produto esgotado quando o estoque é zero.
5. **Pedidos pendentes sem conclusão:** o histórico agora permite confirmar ou cancelar. A confirmação baixa estoque, o cancelamento de confirmados o devolve, e repetir a mesma ação não repete o movimento. Cancelados não são reabertos.
6. **Reenvio de formulário:** cada formulário de novo pedido tem identificador de uso único na sessão, impedindo duplicação pelo reenvio da mesma submissão. Novos lançamentos deliberados continuam permitidos.
7. **Valores inválidos:** campos monetários rejeitam letras, números negativos, múltiplos separadores e valores acima da capacidade do banco. Quantidades são inteiras, e textos têm limites coerentes com o banco.
8. **Histórico alterado pelo produto:** o tipo do pedido usa o valor histórico salvo, e produtos com pedidos não podem mudar entre próprio e afiliado. O valor unitário do pedido é baseado no total registrado, não no preço atual da vitrine.
9. **Login de loja bloqueada:** a autenticação verifica o estado da conta e da loja. Há limites persistentes de tentativas para cadastro e login.
10. **Senhas e sessões:** cadastro e recuperação usam a mesma validação, respeitando o limite de tamanho do hash. Trocar a senha invalida sessões anteriores na próxima requisição. Sair da conta exige POST e token de formulário.
11. **Recuperação de senha:** mantidos tokens aleatórios de uso único, hash no banco, validade de 30 minutos, limites de envio e mensagem genérica. O token sai da URL antes da renderização; respostas não devem ser armazenadas em cache.
12. **Cliques sem destino:** só são registrados cliques que de fato encaminham a uma oferta válida ou WhatsApp configurado. Produtos próprios sem contato exibem “Contato indisponível”.
13. **Métricas e orientações:** a orientação de poucos cliques agora usa cliques/visualizações. A comparação de vendas e cliques informa que não existe atribuição individual. O gráfico e as consultas usam o fuso configurado na aplicação.
14. **Botão de copiar:** só mostra sucesso depois da confirmação do navegador; em caso de falha, oferece cópia manual.
15. **Layout no celular:** formulários passam a uma coluna; marca e identificação da loja não invadem o conteúdo; o botão de sair permanece disponível.
16. **Textos:** revisão de rótulos e instruções, troca de “dashboard” por “painel” nas mensagens, esclarecimento de estoque zero, comissão, data dos pedidos e métricas. Acentos em nomes portugueses geram links mais previsíveis em novos cadastros; links de lojas já cadastradas não são renomeados.
17. **Falhas operacionais:** erros inesperados têm uma resposta genérica; registros técnicos não imprimem credenciais ou tokens. Guias separados para instalação nova e atualização preservam as configurações existentes.

## Testes executados

- Análise sintática de todos os arquivos PHP com o parser do PHP 8.3.33.
- **45 verificações de regressão em PHP:** valores, acentos, senhas, URLs, telefone, estoque, lucro, isolamento de lojas, confirmação/cancelamento, comissão, limites e tokens inválidos, expirados ou reutilizados.
- **24 verificações das páginas em PHP:** cadastro, login, gravação de produto, vitrine, clique, pedido, duplicação, CSRF, saída da sessão, redefinição da senha e uso da senha nova/antiga.
- **12 verificações de telas em Chromium:** login, painel, produtos, pedidos, configurações e nova senha, em larguras de 1440 e 390 pixels. Sem transbordamento horizontal da página; tabelas têm rolagem própria. Conferência visual de capturas do painel e dos formulários.
- JavaScript sem erros nas telas verificadas; teste de nome de produto contendo HTML renderizado como texto; comissão de afiliado não preenchida com o preço da mercadoria.
- Regras de nomes do Apache verificadas para bloquear credenciais e permitir as páginas de configurações.
- Integridade do ZIP e preservação do `config.php` original do pacote.

## Limites da validação

O PHP foi executado por WebAssembly. Para os testes de dados, foi usado SQLite em memória/arquivo com adaptação de sintaxe exclusivamente no ambiente de teste. **O sistema entregue continua usando MySQL/MariaDB.** O adaptador não é usado na aplicação.

Não foi executado um servidor MySQL/MariaDB ou Apache neste ambiente; bloqueios simultâneos de banco e regras do servidor precisam ser confirmados na hospedagem. Não foi enviado e-mail real. A configuração do domínio, HTTPS, remetente, banco e permissões depende da hospedagem. Portanto, esta revisão não equivale a uma certificação de segurança ou à confirmação de que a instalação já está no ar.

## Reexecutar as verificações locais

Em um terminal com PHP 8.3 ou superior e PDO SQLite:

    php tests/regressao.php

Os testes usam banco SQLite em memória e não acessam o banco de produção. As tabelas e dados são descartados ao terminar. O arquivo é bloqueado para execução pelo navegador. Ele cobre regras de negócio e recuperação; os testes das páginas e de navegador foram realizados separadamente durante a preparação.

Para conferir a configuração da hospedagem sem alterar dados:

    php tools/verificar.php

Finalize com o roteiro de teste real em `COMECE-AQUI.md`.

## Referências técnicas consultadas

- https://www.php.net/manual/en/function.password-hash.php
- https://www.php.net/pdo.transactions.php
- https://www.php.net/manual/en/function.mail.php
- https://developer.wordpress.org/playground/developers/local-development/php-wasm-node/
