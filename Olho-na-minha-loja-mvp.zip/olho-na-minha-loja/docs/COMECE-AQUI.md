# Olho na Minha Loja — instalação e atualização

Este pacote é o sistema completo revisado. Não é necessário que cada cliente tenha um site: ele cria uma conta, cadastra produtos e divulga o link da vitrine no Instagram, TikTok ou WhatsApp. As vendas são registradas manualmente no painel.

## Instalação nova na HostGator

1. Faça backup do site atual. Crie uma pasta separada, por exemplo `public_html/olho/`. Não misture este sistema com a VitrineMix.
2. No cPanel, selecione PHP 8.3 ou superior com a extensão PDO MySQL. O servidor deve oferecer MySQL/MariaDB com tabelas InnoDB e Apache compatível com `.htaccess`.
3. Crie um banco exclusivo e um usuário com permissão nesse banco.
4. No phpMyAdmin, selecione esse banco e importe `sql/database.sql`.
5. Extraia o ZIP no computador e envie o conteúdo da pasta `olho-na-minha-loja` para `public_html/olho/`. Inclua o arquivo oculto `.htaccess`. Não coloque o ZIP ou backups dentro da pasta pública.
6. Edite `config.php`: preencha banco, usuário, senha e o `base_url` com a URL HTTPS completa, como `https://seu-dominio.com.br/olho/`. Verifique também `timezone`; use o fuso da sua operação. O arquivo do pacote ainda contém dados de exemplo e senha a preencher.
7. Ative o certificado HTTPS. Confira se a URL com HTTPS abre sem avisos no navegador.
8. Copie `config.mail.example.php` para `config.mail.php`; configure um remetente real do domínio e troque `enabled` para `true`. Veja `ATIVAR-RECUPERACAO-DE-SENHA.md`.
9. Abra `https://seu-dominio.com.br/olho/register.php` e crie sua conta. Configure o WhatsApp com país e DDD, cadastre um produto próprio com estoque e teste a vitrine em uma janela anônima.
10. Faça o teste completo abaixo antes de liberar o cadastro aos clientes.

## Atualização de uma instalação existente

1. Faça backup dos arquivos E do banco.
2. Preserve o `config.php` e o `config.mail.php` que já estão funcionando na hospedagem. Não os substitua pelos exemplos do pacote.
3. Substitua todos os demais arquivos da aplicação pelas versões deste ZIP, mantendo a estrutura das pastas e incluindo `.htaccess`. As mudanças são integradas; não atualize apenas a tela de login.
4. No banco existente, importe somente `sql/atualizacao-recuperacao-senha.sql`, mesmo se você ainda não quiser ativar o e-mail. A tabela de limites também protege cadastro e login. O script pode ser reaplicado e não apaga dados. Não use `database.sql` para atualizar.
5. Confira o WhatsApp e o estoque de cada produto próprio. Nesta revisão, estoque zero significa esgotado; a versão anterior permitia venda com zero. Registre as quantidades reais antes de divulgar.
6. Os usuários precisarão entrar novamente se estiverem com sessões de versões anteriores.
7. Antes de cancelar pedidos antigos, confira o estoque: a versão anterior tinha falhas na baixa, e o sistema não consegue reconstruir automaticamente movimentos passados incorretos. Corrija o estoque manualmente quando necessário.

## Teste completo na hospedagem

- Criar duas contas e confirmar que cada uma vê apenas sua própria loja, produtos e pedidos.
- Cadastrar um produto próprio com estoque 2, preço R$ 100 e custo R$ 40.
- Abrir o link público, clicar no produto e conferir a abertura do WhatsApp e o registro do clique.
- Registrar uma venda confirmada de uma unidade: estoque 1, receita R$ 100, lucro R$ 60.
- Registrar um pedido pendente; confirmar pelo histórico. O estoque deve baixar apenas na confirmação.
- Tentar vender sem estoque: o sistema deve recusar. Cancelar um pedido confirmado: o estoque deve voltar uma única vez.
- Cadastrar produto afiliado e clicar na oferta. Ao registrar a venda, preencher a COMISSÃO recebida, não o valor total da mercadoria.
- Usar “Esqueci minha senha”, receber o e-mail, trocar a senha e confirmar que a senha antiga e o link usado não funcionam mais.
- Verificar que `/olho/config.php`, `/olho/config.mail.php`, `/olho/sql/database.sql` e `/olho/includes/functions.php` não expõem conteúdo. As pastas internas devem ser bloqueadas pelo Apache.
- Conferir as telas no celular.

## Diagnóstico opcional no terminal

Se a hospedagem oferecer terminal, dentro da pasta do sistema execute:

    php tools/verificar.php

O diagnóstico é somente leitura; verifica versão do PHP, extensão, conexão, tabelas e configuração básica do remetente. Não imprime senhas e não envia e-mails. Esse comando não substitui o teste real de entrega.

## O que não é automático

- Confirmação de vendas e comissões de afiliados.
- Pagamento dentro do sistema ou cobrança de assinatura dos seus clientes.
- Métricas internas do Instagram e do TikTok.
- Upload de imagens e vídeos: nesta versão a foto usa URL pública.
- Conversão individual entre clique e venda: as contagens são independentes.

O gráfico usa a data original do lançamento do pedido e os indicadores usam apenas pedidos confirmados. As contagens de visitas e cliques podem incluir repetições e robôs; não representam visitantes únicos.
