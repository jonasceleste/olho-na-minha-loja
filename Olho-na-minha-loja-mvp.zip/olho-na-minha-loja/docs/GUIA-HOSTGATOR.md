# Guia de publicação na HostGator

O guia completo e atualizado está em **COMECE-AQUI.md**, nesta pasta.

- Instalação nova: pasta separada (`public_html/olho/`), banco exclusivo, importação de `sql/database.sql` e configuração de `config.php`.
- Atualização: preserve `config.php` e `config.mail.php`, substitua os demais arquivos e importe somente `sql/atualizacao-recuperacao-senha.sql`.
- Recuperação de senha: siga também `ATIVAR-RECUPERACAO-DE-SENHA.md`.

Não apague nem substitua o site que já existe em `public_html`. Os clientes criam suas próprias contas pelo endereço `/olho/register.php`, usando o domínio e a pasta que você configurar.
