<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/orders.php';
require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) {
    flash('error', 'Não foi possível validar o formulário.'); redirect_to('pedidos.php');
}
try {
    change_order_status(tenant_id(), (int) post_value('id'), post_value('status'));
    flash('success', 'Situação do pedido atualizada.');
} catch (DomainException $e) { flash('error', $e->getMessage());
} catch (Throwable $e) { error_log('Falha ao atualizar pedido: ' . get_class($e)); flash('error', 'Não foi possível atualizar o pedido.'); }
redirect_to('pedidos.php');
