-- Execute somente este arquivo no banco existente. Nao apaga dados.
CREATE TABLE IF NOT EXISTS password_resets (
 user_id INT UNSIGNED NOT NULL PRIMARY KEY,
 token_hash CHAR(64) NOT NULL,
 expires_at BIGINT NOT NULL,
 UNIQUE KEY uq_reset_token (token_hash),
 CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS password_reset_limits (
 bucket_key CHAR(64) NOT NULL PRIMARY KEY,
 window_start BIGINT NOT NULL,
 attempts INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
