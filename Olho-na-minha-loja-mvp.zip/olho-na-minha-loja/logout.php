<?php
require __DIR__ . '/includes/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) {
    logout_user();
}
redirect_to('index.php');
