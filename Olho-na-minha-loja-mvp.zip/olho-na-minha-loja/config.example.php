<?php

return array(
    'app' => array(
        'name' => 'Olho na Minha Loja',
        'base_url' => 'https://SEU-DOMINIO/olho/',
        'timezone' => 'America/Cuiaba',
        'session_name' => 'olho_na_minha_loja',
    ),
    'db' => array(
        'host' => 'localhost',
        'name' => 'SEU_USUARIO_olho',
        'user' => 'SEU_USUARIO_olho',
        'pass' => 'SUA_SENHA_DO_BANCO',
        'charset' => 'utf8mb4',
    ),
);
