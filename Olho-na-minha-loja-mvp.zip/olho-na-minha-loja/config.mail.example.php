<?php
// Copie para config.mail.php e informe um remetente real do seu dominio.
// Usa o servico de e-mail local da hospedagem (PHP mail), nao SMTP externo.
return array(
    'enabled' => false, // Troque para true depois de configurar o remetente.
    'from' => 'nao-responda@SEU-DOMINIO.com.br',
);
