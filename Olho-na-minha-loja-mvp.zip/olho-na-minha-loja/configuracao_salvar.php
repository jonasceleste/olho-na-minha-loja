<?php
require __DIR__ . '/includes/bootstrap.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) {
    flash('error', 'Não foi possível validar o formulário.');
    redirect_to('configuracoes.php');
}

$storeName = post_value('store_name');
$ownerName = post_value('owner_name');
$whatsapp = preg_replace('/\D/', '', post_value('whatsapp'));
$brandColor = post_value('brand_color', '#3164f4');

if (!valid_text($storeName, 2, 120) || !valid_text($ownerName, 2, 120) || !valid_whatsapp($whatsapp)) {
    flash('error', 'Use nomes de 2 a 120 caracteres e um WhatsApp válido com país e DDD, ou deixe o telefone vazio.');
    redirect_to('configuracoes.php');
}
if (!preg_match('/^#[0-9a-fA-F]{6}$/', $brandColor)) {
    $brandColor = '#3164f4';
}

$stmt = db()->prepare('UPDATE tenants SET name = ?, owner_name = ?, whatsapp = ?, brand_color = ? WHERE id = ?');
$stmt->execute(array($storeName, $ownerName, $whatsapp ?: null, $brandColor, tenant_id()));
$userStmt = db()->prepare('UPDATE users SET name = ? WHERE id = ? AND tenant_id = ?');
$userStmt->execute(array($ownerName, (int) current_user()['id'], tenant_id()));
flash('success', 'Configurações atualizadas.');
redirect_to('configuracoes.php');
