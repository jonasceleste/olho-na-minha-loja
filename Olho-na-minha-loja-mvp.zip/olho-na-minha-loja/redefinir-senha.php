<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/password_reset.php';
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
// Remove o segredo da URL antes de renderizar a pagina.
if (isset($_GET['token'])) {
    unset($_SESSION['reset_token']);
    if (reset_token_valid($_GET['token'])) { $_SESSION['reset_token'] = $_GET['token']; }
    redirect_to('redefinir-senha.php');
}
$error = ''; $valid = false;
$token = isset($_SESSION['reset_token']) ? $_SESSION['reset_token'] : '';
try {
    if (reset_token_valid($token)) {
        $s = db()->prepare('SELECT user_id FROM password_resets WHERE token_hash = ? AND expires_at > ?');
        $s->execute(array(hash('sha256', $token), time()));
        $valid = (bool) $s->fetch();
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $valid) {
        $password = isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : '';
        $confirm = isset($_POST['confirm_password']) && is_string($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
        if (!verify_csrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) {
            $error = 'A sessão expirou. Atualize a página e tente novamente.';
        } elseif (!valid_password($password)) {
            $error = 'Use pelo menos 8 caracteres, sem espaços no início ou no fim. Se a senha for muito longa, reduza seu tamanho.';
        } elseif ($password !== $confirm) {
            $error = 'As senhas não conferem.';
        } elseif (complete_password_reset($token, $password)) {
            $_SESSION = array();
            session_regenerate_id(true);
            flash('success', 'Senha alterada! Entre com sua nova senha.');
            redirect_to('index.php');
        } else { $valid = false; }
    }
} catch (Throwable $e) {
    error_log('Olho na Minha Loja: falha ao redefinir senha. Verifique banco e migracao.');
    $error = 'Não foi possível concluir agora. Tente novamente mais tarde.';
    $valid = false;
}
$page_title = 'Nova senha';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-panel" style="min-height:100vh"><div class="auth-card">
<span class="eyebrow">OLHO NA MINHA LOJA</span><h2>Crie sua nova senha</h2>
<?php if ($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>
<?php if ($valid): ?>
<p>Use uma senha com pelo menos 8 caracteres.</p>
<form method="post" action="<?php echo e(app_url('redefinir-senha.php')); ?>">
<input type="hidden" name="_csrf" value="<?php echo e(csrf_token()); ?>">
<div class="field"><label for="password">Nova senha</label><input id="password" name="password" type="password" minlength="8" maxlength="72" autocomplete="new-password" required></div>
<div class="field"><label for="confirm_password">Confirme a nova senha</label><input id="confirm_password" name="confirm_password" type="password" minlength="8" maxlength="72" autocomplete="new-password" required></div>
<button class="button button-primary button-block">Salvar nova senha</button></form>
<?php else: ?><p>Este link é inválido, expirou ou já foi utilizado.</p><a class="button button-primary" href="<?php echo e(app_url('esqueci-senha.php')); ?>">Solicitar outro link</a><?php endif; ?>
<div class="auth-footer"><a href="<?php echo e(app_url('index.php')); ?>">Voltar para o login</a></div>
</div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
