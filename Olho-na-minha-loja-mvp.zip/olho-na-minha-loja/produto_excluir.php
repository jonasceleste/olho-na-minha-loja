<?php
require __DIR__ . '/includes/bootstrap.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) {
    $stmt = db()->prepare('UPDATE products SET status = "archived" WHERE id = ? AND tenant_id = ?');
    $stmt->execute(array((int) post_value('id', '0'), tenant_id()));
    if ($stmt->rowCount() > 0) { flash('success', 'Produto arquivado e retirado da loja pública.'); }
    else { flash('error', 'Produto não encontrado ou já arquivado.'); }
} else {
    flash('error', 'Não foi possível arquivar o produto.');
}
redirect_to('produtos.php');
