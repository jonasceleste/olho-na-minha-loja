<?php
require __DIR__ . '/includes/bootstrap.php';

$productId = (int) input_value($_GET, 'product', '0');
$source = preg_replace('/[^a-zA-Z0-9_-]/', '', input_value($_GET, 'source', 'store'));
$stmt = db()->prepare('SELECT p.*, t.name AS tenant_name, t.slug AS tenant_slug, t.whatsapp AS tenant_whatsapp, t.status AS tenant_status FROM products p INNER JOIN tenants t ON t.id = p.tenant_id WHERE p.id = ? AND p.status = "published" LIMIT 1');
$stmt->execute(array($productId));
$product = $stmt->fetch();

if (!$product || $product['tenant_status'] !== 'active') {
    http_response_code(404);
    echo 'Oferta não encontrada.';
    exit;
}



if ($product['sale_type'] === 'affiliate') {
    if (valid_http_url($product['affiliate_url'])) {
        record_click($product['tenant_id'], $product['id'], $source ?: 'store');
        redirect_to($product['affiliate_url']);
    }
    http_response_code(410);
    echo 'O link desta oferta precisa ser atualizado pelo responsável da loja.';
    exit;
}

if ((int) $product['stock_qty'] <= 0) { http_response_code(410); echo 'Este produto está esgotado.'; exit; }

$message = 'Olá! Tenho interesse no produto: ' . $product['name'] . '. Preço anunciado: ' . money($product['price']) . '.';
$whatsapp = whatsapp_url($product['tenant_whatsapp'], $message);
if ($whatsapp !== '' && valid_whatsapp($product['tenant_whatsapp'])) {
    record_click($product['tenant_id'], $product['id'], $source ?: 'store');
    redirect_to($whatsapp);
}

redirect_to('loja.php?slug=' . rawurlencode($product['tenant_slug']) . '#produto-' . (int) $product['id']);
