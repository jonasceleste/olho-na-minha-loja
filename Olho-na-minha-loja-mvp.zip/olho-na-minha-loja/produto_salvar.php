<?php
require __DIR__ . '/includes/bootstrap.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) {
    flash('error', 'Não foi possível validar o formulário.');
    redirect_to('produtos.php');
}

$tenantId = tenant_id();
$id = (int) post_value('id', '0');
$saleType = post_value('sale_type');
$name = post_value('name');
$price = to_float(post_value('price'));
$costPrice = to_float(post_value('cost_price'));
$stockQty = positive_integer(post_value('stock_qty', '0'), 0);
$category = post_value('category');
$imageUrl = post_value('image_url');
$affiliateUrl = post_value('affiliate_url');
$description = post_value('description');
$status = post_value('status', 'published');

if (!in_array($saleType, array('own', 'affiliate'), true)) {
    $saleType = 'own';
}
if (!in_array($status, array('draft', 'published'), true)) {
    $status = 'published';
}

if (!valid_text($name, 2, 180) || $price === null || $price <= 0 || $costPrice === null || $stockQty === null || !valid_text($category, 0, 80) || !valid_text($description, 0, 5000) || strlen($imageUrl) > 500 || strlen($affiliateUrl) > 1000) {
    flash('error', 'Revise os campos: nome de 2 a 180 caracteres, preço positivo, custo válido e estoque inteiro de 0 a 1.000.000. Categoria: até 80 caracteres; descrição: até 5.000.');
    redirect_to('produtos.php' . ($id ? '?edit=' . $id : ''));
}
if ($imageUrl !== '' && !valid_http_url($imageUrl)) {
    flash('error', 'A imagem precisa ser uma URL válida iniciada por http:// ou https://.');
    redirect_to('produtos.php' . ($id ? '?edit=' . $id : ''));
}
if ($saleType === 'affiliate' && !valid_http_url($affiliateUrl)) {
    flash('error', 'Informe um link válido para a oferta afiliada.');
    redirect_to('produtos.php' . ($id ? '?edit=' . $id : ''));
}
if ($saleType === 'own') {
    $affiliateUrl = null;
}

if ($id > 0) {
    $owned = db()->prepare('SELECT id, sale_type FROM products WHERE id = ? AND tenant_id = ?');
    $owned->execute(array($id, $tenantId));
    $existing = $owned->fetch();
    if (!$existing) { flash('error', 'Produto não encontrado na sua loja.'); redirect_to('produtos.php'); }
    if ($existing['sale_type'] !== $saleType) {
        $history = db()->prepare('SELECT oi.id FROM order_items oi INNER JOIN orders o ON o.id = oi.order_id WHERE oi.product_id = ? AND o.tenant_id = ? LIMIT 1');
        $history->execute(array($id, $tenantId));
        if ($history->fetch()) { flash('error', 'Este produto tem pedidos. Cadastre outro produto para mudar o tipo de venda.'); redirect_to('produtos.php'); }
    }
}
if ($saleType === 'own' && $status === 'published' && !valid_whatsapp((string) current_tenant()['whatsapp'])) {
    flash('error', 'Configure um WhatsApp válido antes de publicar produtos próprios.'); redirect_to('produtos.php');
}
if ($saleType === 'own' && $status === 'published' && empty(current_tenant()['whatsapp'])) {
    flash('error', 'Configure o WhatsApp da loja antes de publicar produtos próprios.'); redirect_to('produtos.php');
}
$baseSlug = substr(slugify($name), 0, 150);
$productSlug = $baseSlug;
$number = 2;
$slugStmt = db()->prepare('SELECT id FROM products WHERE tenant_id = ? AND slug = ? AND id <> ? LIMIT 1');
while (true) {
    $slugStmt->execute(array($tenantId, $productSlug, $id));
    if (!$slugStmt->fetch()) {
        break;
    }
    $productSlug = $baseSlug . '-' . $number;
    $number++;
}

if ($id > 0) {
    $stmt = db()->prepare('UPDATE products SET sale_type = ?, name = ?, slug = ?, description = ?, category = ?, image_url = ?, affiliate_url = ?, price = ?, cost_price = ?, stock_qty = ?, status = ? WHERE id = ? AND tenant_id = ?');
    $stmt->execute(array($saleType, $name, $productSlug, $description ?: null, $category ?: null, $imageUrl ?: null, $affiliateUrl, $price, $costPrice, $stockQty, $status, $id, $tenantId));
    flash('success', 'Produto atualizado com sucesso.');
} else {
    $stmt = db()->prepare('INSERT INTO products (tenant_id, sale_type, name, slug, description, category, image_url, affiliate_url, price, cost_price, stock_qty, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute(array($tenantId, $saleType, $name, $productSlug, $description ?: null, $category ?: null, $imageUrl ?: null, $affiliateUrl, $price, $costPrice, $stockQty, $status));
    flash('success', 'Produto adicionado à sua loja.');
}

redirect_to('produtos.php');
