<?php
require __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/password_reset.php';

if (current_user()) {
    redirect_to('dashboard.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) {
        $error = 'A sessão expirou. Atualize a página e tente novamente.';
    } else {
        $email = strtolower(post_value('email'));
        $password = post_value('password');
        $allowed = reset_rate_allow('login-ip:' . input_value($_SERVER, 'REMOTE_ADDR', 'unknown'), 60)
            && reset_rate_allow('login-email:' . $email, 20);
        $stmt = db()->prepare('SELECT u.id, u.password_hash FROM users u INNER JOIN tenants t ON t.id = u.tenant_id WHERE u.email = ? AND u.status = "active" AND t.status = "active" LIMIT 1');
        $stmt->execute(array($email));
        $user = $stmt->fetch();

        if ($allowed && $user && strlen($password) <= 72 && password_verify($password, $user['password_hash'])) {
            login_user($user['id']);
            redirect_to('dashboard.php');
        }
        $error = $allowed ? 'E-mail ou senha não conferem.' : 'Muitas tentativas. Aguarde até uma hora antes de tentar novamente.';
    }
}

$page_title = 'Entrar';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-page">
    <section class="auth-showcase">
        <a class="auth-brand" href="<?php echo e(app_url('index.php')); ?>">
            <span class="brand-mark">O</span>
            <span><strong>Olho na</strong><small>Minha Loja</small></span>
        </a>
        <h1>Enxergue o que faz sua loja crescer.</h1>
        <p>Um painel simples para acompanhar visualizações, cliques, pedidos, vendas e lucro de cada loja em um só lugar.</p>
        <div class="auth-points">
            <div class="auth-point"><strong>01</strong><span>Link exclusivo para cada cliente</span></div>
            <div class="auth-point"><strong>02</strong><span>Produtos próprios e afiliados</span></div>
            <div class="auth-point"><strong>03</strong><span>Decisões baseadas em dados</span></div>
        </div>
    </section>
    <section class="auth-panel">
        <div class="auth-card">
            <span class="eyebrow">ÁREA DO CLIENTE</span>
            <h2>Bem-vindo de volta</h2>
            <p>Entre para ver os números da sua loja e descobrir onde melhorar.</p>
            <?php if ($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>
            <?php if ($message = flash('error')): ?><div class="alert alert-error"><?php echo e($message); ?></div><?php endif; ?>
            <?php if ($message = flash('success')): ?><div class="notice" role="status"><?php echo e($message); ?></div><?php endif; ?>
            <form method="post" action="<?php echo e(app_url('index.php')); ?>">
                <input type="hidden" name="_csrf" value="<?php echo e(csrf_token()); ?>">
                <div class="field"><label for="email">E-mail</label><input id="email" name="email" maxlength="190" type="email" autocomplete="email" required></div>
                <div class="field"><label for="password">Senha</label><input id="password" name="password" type="password" autocomplete="current-password" required></div>
                <button class="button button-primary button-block" type="submit">Entrar no painel</button>
            </form>
            <div class="auth-footer"><a href="<?php echo e(app_url('esqueci-senha.php')); ?>">Esqueci minha senha</a></div>
            <div class="auth-footer">Ainda não tem uma conta? <a href="<?php echo e(app_url('register.php')); ?>">Criar minha loja</a></div>
        </div>
    </section>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
