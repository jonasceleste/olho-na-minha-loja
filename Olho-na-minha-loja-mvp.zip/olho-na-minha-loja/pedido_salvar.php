<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/orders.php';
require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) {
    flash('error', 'Não foi possível validar o formulário.'); redirect_to('pedidos.php');
}
if (empty($_SESSION['order_nonce']) || !hash_equals($_SESSION['order_nonce'], post_value('order_nonce'))) {
    flash('error', 'Este formulário já foi enviado ou expirou. Confira o histórico antes de registrar outro pedido.'); redirect_to('pedidos.php');
}
$productId = positive_integer(post_value('product_id'), 1, 2147483647);
$quantity = positive_integer(post_value('quantity'));
$revenue = to_float(post_value('revenue'));
$costTotal = to_float(post_value('cost_total'));
$status = post_value('status');
$customerName = post_value('customer_name');
$notes = post_value('notes');
if ($productId === null || $quantity === null || $revenue === null || $revenue <= 0 || $costTotal === null
    || !in_array($status, array('paid', 'pending', 'cancelled'), true)
    || !valid_text($customerName, 0, 120) || !valid_text($notes, 0, 500)) {
    flash('error', 'Revise produto, quantidade, valores e textos. O valor da venda deve ser positivo; não use valores negativos.'); redirect_to('pedidos.php');
}
try {
    create_order(tenant_id(), $productId, $quantity, $revenue, $costTotal, $status, $customerName, $notes);
    unset($_SESSION['order_nonce']);
    flash('success', 'Pedido registrado. Os indicadores do painel foram atualizados.');
} catch (DomainException $e) { flash('error', $e->getMessage());
} catch (Throwable $e) { error_log('Falha ao registrar pedido: ' . get_class($e)); flash('error', 'Não foi possível registrar o pedido. Tente novamente.'); }
redirect_to('pedidos.php');
